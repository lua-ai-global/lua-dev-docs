<?php
/**
 * Plugin Name: Lua Shopping Assistant
 * Plugin URI: https://lua.dev/woocommerce
 * Description: AI-powered shopping assistant for WooCommerce stores with customizable chat widget and admin integration.
 * Version: 1.4.5
 * Author: Lua AI
 * Author URI: https://lua.dev
 * Text Domain: lua-shopping-assistant
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.5
 * License: GPL v3 or later
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 * Network: false
 * 
 * Note: This plugin is compatible with both traditional WooCommerce storage and 
 * High-Performance Order Storage (HPOS).
 *
 * @package LuaShoppingAssistant
 */

// Declare HPOS compatibility
add_action( 'before_woocommerce_init', function() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
});

defined( 'ABSPATH' ) || exit;

// Load configuration
require_once plugin_dir_path( __FILE__ ) . 'config.php';

// Prevent multiple plugin instances
if ( defined( 'LUA_SHOPPING_ASSISTANT_LOADED' ) ) {
	return;
}
define( 'LUA_SHOPPING_ASSISTANT_LOADED', true );

// Prevent conflicts with old plugin versions
$plugin_dir = plugin_dir_path( __FILE__ );
$plugin_basename = plugin_basename( __FILE__ );

// Only show the old version warning if we detect multiple versions of the plugin
// This prevents false positives during development
$all_plugins = get_plugins();
$lua_plugins = array();
foreach ( $all_plugins as $plugin_file => $plugin_data ) {
	if ( strpos( $plugin_file, 'lua-shopping-assistant' ) !== false ) {
		$lua_plugins[ $plugin_file ] = $plugin_data;
	}
}

// If we have multiple versions AND the current one doesn't have a version number
if ( count( $lua_plugins ) > 1 && 
     strpos( $plugin_dir, 'lua-shopping-assistant-v' ) === false && 
     strpos( $plugin_dir, 'lua-shopping-assistant/' ) !== false ) {
	// This is an old version without version number, deactivate it
	if ( is_admin() ) {
		add_action( 'admin_notices', function() {
			echo '<div class="error"><p><strong>Lua Shopping Assistant:</strong> Please deactivate and delete the old plugin version and install the latest version.</p></div>';
		});
	}
	return;
}

/**
 * Detect and handle version conflicts.
 *
 * @since 1.1.3
 */
if ( ! function_exists( 'lua_shopping_assistant_detect_version_conflicts' ) ) {
	function lua_shopping_assistant_detect_version_conflicts() {
		// Get all active plugins
		$active_plugins = get_option( 'active_plugins', array() );
		$lua_plugins = array();
		
		// Find all Lua Shopping Assistant plugins
		foreach ( $active_plugins as $plugin_file ) {
			if ( strpos( $plugin_file, 'lua-shopping-assistant' ) !== false ) {
				$lua_plugins[] = $plugin_file;
			}
		}
		
		// If multiple versions are active, deactivate all but the newest
		if ( count( $lua_plugins ) > 1 ) {
			// Sort by version number (newest first)
			usort( $lua_plugins, function( $a, $b ) {
				// Extract version numbers from plugin paths
				preg_match( '/lua-shopping-assistant-v?(\d+\.\d+\.\d+)/', $a, $matches_a );
				preg_match( '/lua-shopping-assistant-v?(\d+\.\d+\.\d+)/', $b, $matches_b );
				
				$version_a = isset( $matches_a[1] ) ? $matches_a[1] : '0.0.0';
				$version_b = isset( $matches_b[1] ) ? $matches_b[1] : '0.0.0';
				
				return version_compare( $version_b, $version_a );
			});
			
			// Keep the first (newest) plugin, deactivate the rest
			$newest_plugin = array_shift( $lua_plugins );
			
			foreach ( $lua_plugins as $old_plugin ) {
				deactivate_plugins( $old_plugin );
				error_log( 'Lua Shopping Assistant: Deactivated conflicting version: ' . $old_plugin );
			}
			
			// Show admin notice
			if ( is_admin() ) {
				add_action( 'admin_notices', function() use ( $lua_plugins ) {
					$count = count( $lua_plugins );
					echo '<div class="notice notice-warning is-dismissible">';
					echo '<p><strong>Lua Shopping Assistant:</strong> ' . 
						 sprintf( _n( 
							 'Deactivated %d conflicting plugin version.', 
							 'Deactivated %d conflicting plugin versions.', 
							 $count, 
							 'lua-shopping-assistant' 
						 ), $count ) . 
						 ' Only the newest version is active.</p>';
					echo '</div>';
				});
			}
		}
	}
}

// Enhanced version conflict detection - call after function definition
lua_shopping_assistant_detect_version_conflicts();

if ( ! defined( 'MAIN_PLUGIN_FILE' ) ) {
	define( 'MAIN_PLUGIN_FILE', __FILE__ );
}

// Include the setup class
require_once plugin_dir_path( __FILE__ ) . 'includes/admin/setup.php';

// phpcs:disable WordPress.Files.FileName

/**
 * WooCommerce fallback notice.
 *
 * @since 0.1.0
 */
if ( ! function_exists( 'lua_shopping_assistant_missing_wc_notice' ) ) {
	function lua_shopping_assistant_missing_wc_notice() {
		/* translators: %s WC download URL link. */
		echo '<div class="error"><p><strong>' . sprintf( esc_html__( 'Lua Shopping Assistant requires WooCommerce to be installed and active. You can download %s here.', 'lua_shopping_assistant' ), '<a href="https://woo.com/" target="_blank">WooCommerce</a>' ) . '</strong></p></div>';
	}
}

register_activation_hook( __FILE__, 'lua_shopping_assistant_activate' );
register_deactivation_hook( __FILE__, 'lua_shopping_assistant_deactivate' );

/**
 * Clean up old versions of the plugin.
 *
 * @since 1.1.3
 */
if ( ! function_exists( 'lua_shopping_assistant_cleanup_old_versions' ) ) {
	function lua_shopping_assistant_cleanup_old_versions() {
		// Get all plugins
		$all_plugins = get_plugins();
		$current_plugin_file = plugin_basename( __FILE__ );
		$current_plugin_dir = dirname( $current_plugin_file );
		
		// Find all Lua Shopping Assistant plugins
		$lua_plugins = array();
		foreach ( $all_plugins as $plugin_file => $plugin_data ) {
			if ( strpos( $plugin_file, 'lua-shopping-assistant' ) !== false ) {
				$lua_plugins[ $plugin_file ] = $plugin_data;
			}
		}
		
		// If we have multiple versions, deactivate and delete old ones
		if ( count( $lua_plugins ) > 1 ) {
			foreach ( $lua_plugins as $plugin_file => $plugin_data ) {
				// Skip the current plugin
				if ( $plugin_file === $current_plugin_file ) {
					continue;
				}
				
				// Deactivate the old plugin
				if ( is_plugin_active( $plugin_file ) ) {
					deactivate_plugins( $plugin_file );
					error_log( 'Lua Shopping Assistant: Deactivated old version: ' . $plugin_file );
				}
				
				// Delete the old plugin files
				$plugin_dir = WP_PLUGIN_DIR . '/' . dirname( $plugin_file );
				if ( is_dir( $plugin_dir ) ) {
					// Use WordPress filesystem API for safe deletion
					if ( ! function_exists( 'WP_Filesystem' ) ) {
						require_once ABSPATH . 'wp-admin/includes/file.php';
					}
					
					WP_Filesystem();
					global $wp_filesystem;
					
					if ( $wp_filesystem->delete( $plugin_dir, true ) ) {
						error_log( 'Lua Shopping Assistant: Deleted old version directory: ' . $plugin_dir );
					} else {
						error_log( 'Lua Shopping Assistant: Failed to delete old version directory: ' . $plugin_dir );
					}
				}
			}
			
			// Clear plugin cache
			wp_cache_delete( 'plugins', 'plugins' );
			
			error_log( 'Lua Shopping Assistant: Cleanup completed - old versions removed' );
		}
	}
}

/**
 * Activation hook.
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'lua_shopping_assistant_activate' ) ) {
	function lua_shopping_assistant_activate() {
	// Check if WooCommerce is active
	if ( ! class_exists( 'WooCommerce' ) ) {
		deactivate_plugins( plugin_basename( __FILE__ ) );
		wp_die( 
			esc_html__( 'Lua Shopping Assistant requires WooCommerce to be installed and active. Please install WooCommerce first.', 'lua-shopping-assistant' ),
			esc_html__( 'Plugin Activation Error', 'lua-shopping-assistant' ),
			array( 'back_link' => true )
		);
	}

	// Check minimum PHP version
	if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
		deactivate_plugins( plugin_basename( __FILE__ ) );
		wp_die( 
			esc_html__( 'Lua Shopping Assistant requires PHP 7.4 or higher. Your current PHP version is ' . PHP_VERSION, 'lua-shopping-assistant' ),
			esc_html__( 'Plugin Activation Error', 'lua-shopping-assistant' ),
			array( 'back_link' => true )
		);
	}

	// Check minimum WordPress version
	if ( version_compare( get_bloginfo( 'version' ), '5.0', '<' ) ) {
		deactivate_plugins( plugin_basename( __FILE__ ) );
		wp_die( 
			esc_html__( 'Lua Shopping Assistant requires WordPress 5.0 or higher.', 'lua-shopping-assistant' ),
			esc_html__( 'Plugin Activation Error', 'lua-shopping-assistant' ),
			array( 'back_link' => true )
		);
	}

	// HPOS compatibility is now supported - no blocking needed

	// Clean up old versions of the plugin
	lua_shopping_assistant_cleanup_old_versions();

	// Set default options
	$default_options = array(
		'lua_widget_enabled' => 0,
		'lua_widget_position' => 'bottom-right',
		'lua_widget_theme' => 'light',
		'lua_widget_button_text' => get_bloginfo( 'name' ) . ' Assistant',
		'lua_widget_chat_title' => get_bloginfo( 'name' ) . ' Assistant',
		'lua_widget_button_icon' => '',
		'lua_widget_button_color' => '#000000',
		'lua_widget_chat_height' => 600,
		'lua_widget_chat_width' => 400,
		'lua_widget_voice_enabled' => 1,
		'lua_widget_bottom_position' => 75,
		'lua_widget_right_position' => 20,
	);

	foreach ( $default_options as $option => $value ) {
		if ( get_option( $option ) === false ) {
			add_option( $option, $value );
		}
	}

	// Flush rewrite rules
	flush_rewrite_rules();
	}
}

/**
 * Deactivation hook.
 *
 * @since 1.0.0
 */
if ( ! function_exists( 'lua_shopping_assistant_deactivate' ) ) {
	function lua_shopping_assistant_deactivate() {
		// Flush rewrite rules
		flush_rewrite_rules();
		
		// Clean up any orphaned plugin files
		lua_shopping_assistant_cleanup_orphaned_files();
		
		error_log( 'Lua Shopping Assistant: Plugin deactivated' );
	}
}

/**
 * Clean up orphaned plugin files.
 *
 * @since 1.1.3
 */
if ( ! function_exists( 'lua_shopping_assistant_cleanup_orphaned_files' ) ) {
	function lua_shopping_assistant_cleanup_orphaned_files() {
		$plugin_dir = WP_PLUGIN_DIR;
		$lua_dirs = glob( $plugin_dir . '/lua-shopping-assistant*', GLOB_ONLYDIR );
		
		foreach ( $lua_dirs as $dir ) {
			// Skip if this is the current plugin directory
			if ( $dir === plugin_dir_path( __FILE__ ) ) {
				continue;
			}
			
			// Check if this directory contains an old version
			$plugin_file = $dir . '/lua-shopping-assistant.php';
			if ( file_exists( $plugin_file ) ) {
				// Read the plugin header to get version
				$plugin_data = get_plugin_data( $plugin_file );
				$version = isset( $plugin_data['Version'] ) ? $plugin_data['Version'] : '0.0.0';
				
				// If it's an old version, delete it
				if ( version_compare( $version, '1.1.3', '<' ) ) {
					if ( ! function_exists( 'WP_Filesystem' ) ) {
						require_once ABSPATH . 'wp-admin/includes/file.php';
					}
					
					WP_Filesystem();
					global $wp_filesystem;
					
					if ( $wp_filesystem->delete( $dir, true ) ) {
						error_log( 'Lua Shopping Assistant: Cleaned up orphaned version ' . $version . ' from ' . $dir );
					}
				}
			}
		}
	}
}

if ( ! class_exists( 'lua_shopping_assistant' ) ) :
	/**
	 * The lua_shopping_assistant class.
	 */
	class lua_shopping_assistant {
		/**
		 * Plugin version.
		 *
		 * @var string
		 */
		private $version = '1.4.5';

		/**
		 * This class instance.
		 *
		 * @var \lua_shopping_assistant single instance of this class.
		 */
		private static $instance;

		/**
		 * Constructor.
		 */
		public function __construct() {
			// Always instantiate Setup for REST API routes, but only load admin scripts when in admin
			new \LuaShoppingAssistant\Admin\Setup();
		}

		/**
		 * Cloning is forbidden.
		 */
		public function __clone() {
			if ( function_exists( 'wc_doing_it_wrong' ) ) {
				wc_doing_it_wrong( __FUNCTION__, __( 'Cloning is forbidden.', 'lua_shopping_assistant' ), $this->version );
			}
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 */
		public function __wakeup() {
			if ( function_exists( 'wc_doing_it_wrong' ) ) {
				wc_doing_it_wrong( __FUNCTION__, __( 'Unserializing instances of this class is forbidden.', 'lua_shopping_assistant' ), $this->version );
			}
		}

		/**
		 * Gets the main instance.
		 *
		 * Ensures only one instance can be loaded.
		 *
		 * @return \lua_shopping_assistant
		 */
		public static function instance() {

			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}
	}
endif;

add_action( 'plugins_loaded', 'lua_shopping_assistant_init', 10 );

/**
 * Initialize the plugin.
 *
 * @since 0.1.0
 */
if ( ! function_exists( 'lua_shopping_assistant_init' ) ) {
	function lua_shopping_assistant_init() {
	load_plugin_textdomain( 'lua_shopping_assistant', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );

	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'lua_shopping_assistant_missing_wc_notice' );
		return;
	}

		lua_shopping_assistant::instance();

	}
}
