<?php
/**
 * Uninstall script for Lua Shopping Assistant
 *
 * @package LuaShoppingAssistant
 */

// If uninstall not called from WordPress, then exit
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Load WordPress
require_once dirname( __FILE__ ) . '/../../wp-config.php';

// Clean up plugin options
$options_to_remove = array(
	'lua_widget_enabled',
	'lua_widget_position',
	'lua_widget_theme',
	'lua_widget_button_text',
	'lua_widget_chat_title',
	'lua_widget_button_icon',
	'lua_widget_button_color',
	'lua_widget_chat_height',
	'lua_widget_chat_width',
	'lua_widget_voice_enabled',
	'lua_widget_bottom_position',
	'lua_widget_right_position',
	'lua_api_key',
	'lua_api_secret',
	'lua_store_id',
	'lua_onboarding_completed',
	'lua_demo_products_created',
);

foreach ( $options_to_remove as $option ) {
	delete_option( $option );
}

// Clean up user meta
global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'lua_%'" );

// Clean up transients
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_lua_%'" );
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_lua_%'" );

// Clean up any custom tables if they exist
// (Add any custom table cleanup here if needed)

// Log uninstall





