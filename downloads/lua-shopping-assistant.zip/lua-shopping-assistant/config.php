<?php
/**
 * Configuration file for Lua Shopping Assistant
 *
 * @package LuaShoppingAssistant
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin constants
define( 'LUA_SHOPPING_ASSISTANT_VERSION', '1.4.5' );
define( 'LUA_SHOPPING_ASSISTANT_PLUGIN_FILE', __FILE__ );
define( 'LUA_SHOPPING_ASSISTANT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'LUA_SHOPPING_ASSISTANT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'LUA_SHOPPING_ASSISTANT_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// WooCommerce integration
define( 'LUA_SHOPPING_ASSISTANT_WC_MIN_VERSION', '5.0' );
define( 'LUA_SHOPPING_ASSISTANT_WC_TESTED_VERSION', '8.9' );

// API endpoints
define( 'LUA_SHOPPING_ASSISTANT_API_NAMESPACE', 'lua/v1' );
define( 'LUA_SHOPPING_ASSISTANT_API_BASE', 'lua-shopping-assistant' );

// Default settings
define( 'LUA_SHOPPING_ASSISTANT_DEFAULT_WIDGET_ENABLED', false );
define( 'LUA_SHOPPING_ASSISTANT_DEFAULT_WIDGET_POSITION', 'bottom-right' );
define( 'LUA_SHOPPING_ASSISTANT_DEFAULT_WIDGET_THEME', 'light' );
define( 'LUA_SHOPPING_ASSISTANT_DEFAULT_CHAT_HEIGHT', 600 );
define( 'LUA_SHOPPING_ASSISTANT_DEFAULT_CHAT_WIDTH', 400 );

// Debug mode
define( 'LUA_SHOPPING_ASSISTANT_DEBUG', defined( 'WP_DEBUG' ) && WP_DEBUG );

define( 'LUA_AUTH_URL', 'https://auth.heylua.ai' );
define( 'LUA_ENVIRONMENT', 'production' );
