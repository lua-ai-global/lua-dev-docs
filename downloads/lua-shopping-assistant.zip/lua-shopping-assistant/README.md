# Lua Shopping Assistant

AI-powered shopping assistant for WooCommerce stores with customizable chat widget and admin integration.

## Features

- **AI Chat Widget**: Customizable chat interface for customer support
- **Admin Integration**: Easy setup and configuration through WordPress admin
- **Demo Products**: Quick setup with sample products
- **Widget Settings**: Customize appearance, position, and behavior
- **REST API**: Full API integration for advanced functionality

## Installation

1. Upload the plugin files to `/wp-content/plugins/lua-shopping-assistant/`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Navigate to WooCommerce > Lua Shopping Assistant to configure

## Requirements

- WordPress 5.0 or higher
- WooCommerce 5.0 or higher
- PHP 7.4 or higher

## Configuration

1. Go to **WooCommerce > Lua Shopping Assistant** in your WordPress admin
2. Complete the onboarding process
3. Configure widget settings under **WooCommerce > Lua Widget Settings**
4. Add demo products if needed under **WooCommerce > Demo Products**

## Support

For support and documentation, visit [Lua AI](https://heylua.ai/woocommerce).

## License

GPL v3 or later
