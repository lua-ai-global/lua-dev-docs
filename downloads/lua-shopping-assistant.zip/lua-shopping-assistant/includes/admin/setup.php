<?php

namespace LuaShoppingAssistant\Admin;

/**
 * LuaShoppingAssistant Setup Class
 */
if ( ! class_exists( 'LuaShoppingAssistant\Admin\Setup' ) ) {
	class Setup {
	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Debug: Log that the class is being instantiated
		
		// Only load admin-specific hooks when in admin
		if ( is_admin() ) {
			add_action( 'admin_enqueue_scripts', array( $this, 'register_scripts' ) );
			add_action( 'admin_menu', array( $this, 'register_page' ), 20 ); // Higher priority to ensure WooCommerce menu exists
			add_action( 'admin_init', array( $this, 'handle_demo_products_action' ) );
			add_action( 'admin_init', array( $this, 'register_widget_settings' ) );
			add_action( 'admin_notices', array( $this, 'admin_notices' ) );
		}
		
		// Frontend hooks for widget loading
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_scripts' ) );
		add_action( 'wp_footer', array( $this, 'render_lua_pop_widget' ) );
		
		// Hook to handle Lua checkout cart loading - use proper WooCommerce hooks
		add_action( 'wp_loaded', array( $this, 'handle_lua_checkout_cart' ), 20 );
		add_action( 'woocommerce_checkout_init', array( $this, 'handle_lua_checkout_cart' ) );
		
		// AJAX handlers and REST API routes are available everywhere
		add_action( 'wp_ajax_lua_send_otp', array( $this, 'ajax_send_otp' ) );
		add_action( 'wp_ajax_lua_verify_otp', array( $this, 'ajax_verify_otp' ) );
		add_action( 'wp_ajax_lua_create_account', array( $this, 'ajax_create_account' ) );
		add_action( 'wp_ajax_lua_check_rest_api', array( $this, 'ajax_check_rest_api' ) );
		add_action( 'wp_ajax_lua_fetch_app_data', array( $this, 'ajax_fetch_app_data' ) );
		
		// Register REST API routes - use a higher priority to ensure it runs
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ), 10 );
		
		// Debug: Log that hooks have been added
	}

	/**
	 * Load all necessary dependencies.
	 *
	 * @since 1.0.0
	 */
	public function register_scripts() {
		// Load scripts on both WooCommerce admin pages and our custom admin pages
		$is_wc_admin_page = method_exists( 'Automattic\WooCommerce\Admin\PageController', 'is_admin_or_embed_page' ) &&
			\Automattic\WooCommerce\Admin\PageController::is_admin_or_embed_page();
		
		$is_lua_admin_page = isset( $_GET['page'] ) && in_array( sanitize_text_field( wp_unslash( $_GET['page'] ) ), array( 'lua-shopping-assistant', 'lua-widget-settings', 'lua-demo-products' ) );
		
		if ( ! $is_wc_admin_page && ! $is_lua_admin_page ) {
			return;
		}

		$script_path       = '/build/index.js';
		$script_asset_path = dirname( MAIN_PLUGIN_FILE ) . '/build/index.asset.php';
		$script_asset      = file_exists( $script_asset_path )
		? require $script_asset_path
		: array(
			'dependencies' => array(),
			'version'      => filemtime( $script_path ),
		);
		$script_url        = plugins_url( $script_path, MAIN_PLUGIN_FILE );

		wp_register_script(
			'lua-shopping-assistant',
			$script_url,
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);

		wp_register_style(
			'lua-shopping-assistant',
			plugins_url( '/build/index.css', MAIN_PLUGIN_FILE ),
			// Add any dependencies styles may have, such as wp-components.
			array(),
			filemtime( dirname( MAIN_PLUGIN_FILE ) . '/build/index.css' )
		);

		wp_enqueue_script( 'lua-shopping-assistant' );
		wp_enqueue_style( 'lua-shopping-assistant' );
		
		// Debug: Log CSS loading
		
		// Add inline CSS as fallback to ensure styles are applied
		wp_add_inline_style( 'lua-shopping-assistant', '
			.lua-shopping-assistant-admin .lua-onboarding-container {
				background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
				padding: 0 !important;
				min-height: calc(100vh - var(--woocommerce-header-height, 0px) - var(--woocommerce-footer-height, 0px) - var(--woocommerce-primary-margin-top, 0px) - var(--woocommerce-primary-margin-bottom, 0px) - var(--woocommerce-primary-margin-left, 0px)) !important;
				display: flex !important;
				align-items: center !important;
				justify-content: center !important;
				position: relative !important;
			}
			.lua-shopping-assistant-admin .onboarding-step {
				background: white !important;
				padding: 40px !important;
				border-radius: 16px !important;
				box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1) !important;
				margin: 0 !important;
				max-width: 400px !important;
				width: 100% !important;
				position: relative !important;
				z-index: 1 !important;
				text-align: center !important;
			}
			.lua-shopping-assistant-admin .onboarding-step h2 {
				color: #333 !important;
				margin-bottom: 30px !important;
				font-size: 28px !important;
				font-weight: 700 !important;
			}
			.lua-shopping-assistant-admin .onboarding-step .lua-logo {
				width: 60px !important;
				height: 60px !important;
				margin: 0 auto 30px !important;
				background: linear-gradient(45deg, #ff6b6b, #4ecdc4, #45b7d1, #96ceb4, #feca57, #ff9ff3) !important;
				border-radius: 50% !important;
				display: flex !important;
				align-items: center !important;
				justify-content: center !important;
				font-size: 24px !important;
				font-weight: bold !important;
				color: white !important;
			}
		' );

		// Fetch current app data if onboarding is completed
		$app_data = $this->fetch_current_app_data();

		// Localize script with onboarding data
		wp_localize_script( 'lua-shopping-assistant', 'luaOnboardingData', array(
			'nonce' => wp_create_nonce( 'lua_otp_nonce' ),
			'accountNonce' => wp_create_nonce( 'lua_account_nonce' ),
			'isCompleted' => get_option( 'lua_onboarding_completed', false ),
			'woocommerceUrl' => admin_url( 'admin.php?page=woocommerce' ),
			'redirectUri' => get_option( 'lua_redirect_uri', '' ),
		) );
	}

	/**
	 * Register page in wc-admin.
	 *
	 * @since 1.0.0
	 */
	public function register_page() {
		// Debug: Log that we're registering pages
		
		// Ensure WooCommerce is loaded before registering menu items
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		
		// Check if WooCommerce admin menu exists
		global $menu, $submenu;
		$woocommerce_menu_exists = false;
		if ( isset( $menu ) ) {
			foreach ( $menu as $menu_item ) {
				if ( isset( $menu_item[2] ) && $menu_item[2] === 'woocommerce' ) {
					$woocommerce_menu_exists = true;
					break;
				}
			}
		}

		if ( ! function_exists( 'wc_admin_register_page' ) ) {
		} else {
		}

		if ( function_exists( 'wc_admin_register_page' ) ) {
			wc_admin_register_page(
				array(
					'id'     => 'lua_shopping_assistant-example-page',
					'title'  => __( 'Lua Shopping Assistant', 'lua_shopping_assistant' ),
					'parent' => 'woocommerce',
					'path'   => '/lua-shopping-assistant',
				)
			);
		}

		// Note: Main admin page is handled by WooCommerce admin page registration above
		// No need for duplicate traditional WordPress admin page

		// Add widget settings submenu
		$widget_page = add_submenu_page(
			'woocommerce',
			__( 'Lua Widget Settings', 'lua_shopping_assistant' ),
			__( 'Lua Widget Settings', 'lua_shopping_assistant' ),
			'manage_options',
			'lua-widget-settings',
			array( $this, 'widget_settings_page' )
		);
		
		// If WooCommerce menu doesn't exist, try adding to Tools menu as fallback
		if ( ! $widget_page && ! $woocommerce_menu_exists ) {
			$widget_page = add_management_page(
				__( 'Lua Widget Settings', 'lua_shopping_assistant' ),
				__( 'Lua Widget Settings', 'lua_shopping_assistant' ),
				'manage_options',
				'lua-widget-settings',
				array( $this, 'widget_settings_page' )
			);
		}

		// Add demo products submenu
		$demo_page = add_submenu_page(
			'woocommerce',
			__( 'Demo Products', 'lua_shopping_assistant' ),
			__( 'Demo Products', 'lua_shopping_assistant' ),
			'manage_options',
			'lua-demo-products',
			array( $this, 'demo_products_page' )
		);
		
		// If WooCommerce menu doesn't exist, try adding to Tools menu as fallback
		if ( ! $demo_page && ! $woocommerce_menu_exists ) {
			$demo_page = add_management_page(
				__( 'Demo Products', 'lua_shopping_assistant' ),
				__( 'Demo Products', 'lua_shopping_assistant' ),
				'manage_options',
				'lua-demo-products',
				array( $this, 'demo_products_page' )
			);
		}
		
		// Debug: Check if menu items are actually in the global menu
		global $submenu;
		if ( isset( $submenu['woocommerce'] ) ) {
			foreach ( $submenu['woocommerce'] as $item ) {
				if ( strpos( $item[2], 'lua-' ) === 0 ) {
				}
			}
		} else {
		}
	}

	/**
	 * Main admin page callback.
	 *
	 * @since 1.0.0
	 */
	public function main_admin_page() {
		// This will be handled by the React component loaded via register_scripts
		echo '<div id="lua-shopping-assistant-root"></div>';
	}

	/**
	 * Admin notices for debugging.
	 *
	 * @since 1.0.0
	 */
	public function admin_notices() {
		// Only show on our admin pages
		if ( ! isset( $_GET['page'] ) || ! in_array( sanitize_text_field( wp_unslash( $_GET['page'] ) ), array( 'lua-shopping-assistant', 'lua-widget-settings', 'lua-demo-products' ) ) ) {
			return;
		}

		// Check if REST API is working
		$rest_url = rest_url( 'lua/v1/test' );
		echo '<div class="notice notice-info"><p>';
		echo '<strong>Lua Shopping Assistant Debug:</strong><br>';
		echo 'REST API Test URL: <a href="' . esc_url( $rest_url ) . '" target="_blank">' . esc_url( $rest_url ) . '</a><br>';
		echo 'Current Page: ' . esc_html( sanitize_text_field( wp_unslash( $_GET['page'] ) ) );
		echo '</p></div>';
	}

	/**
	 * Handle demo products action.
	 *
	 * @since 1.0.0
	 */
	public function handle_demo_products_action() {
		if ( isset( $_POST['lua_add_demo_products'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lua_demo_products_nonce'] ) ), 'lua_demo_products_action' ) ) {
			$this->create_demo_products();
			wp_safe_redirect( admin_url( 'admin.php?page=lua-demo-products&demo_products_added=1' ) );
			exit;
		}

		if ( isset( $_POST['lua_reset_onboarding'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lua_reset_onboarding_nonce'] ) ), 'lua_reset_onboarding_action' ) ) {
			$this->reset_onboarding();
			wp_safe_redirect( admin_url( 'admin.php?page=lua-demo-products&onboarding_reset=1' ) );
			exit;
		}
	}

	/**
	 * Reset onboarding process.
	 *
	 * @since 1.0.0
	 */
	private function reset_onboarding() {
		// Clear onboarding completion status
		delete_option( 'lua_onboarding_completed' );
		
		// Clear stored authentication data
		delete_option( 'lua_auth_token' );
		delete_option( 'lua_user_email' );
		
		// Clear WooCommerce API credentials
		delete_option( 'lua_wc_consumer_key' );
		delete_option( 'lua_wc_consumer_secret' );
		
		// Log the reset
	}

	/**
	 * Get the authentication API URL.
	 *
	 * @return string Authentication API URL.
	 * @since 1.0.0
	 */
	private function get_auth_url() {
		$auth_url = defined( 'LUA_AUTH_URL' ) ? LUA_AUTH_URL : 'https://auth.lua.dev';
		return rtrim( $auth_url, '/' );
	}

	/**
	 * Get the main API URL.
	 *
	 * @return string Main API URL.
	 * @since 1.0.0
	 */
	private function get_api_url() {
		$api_url = defined( 'LUA_API_URL' ) ? LUA_API_URL : 'https://auth.lua.dev';
		return rtrim( $api_url, '/' );
	}

	/**
	 * AJAX handler for fetching app data.
	 *
	 * @since 1.0.0
	 */
	public function ajax_fetch_app_data() {
		check_ajax_referer( 'lua_otp_nonce', 'nonce' );
		
		
		// Check if onboarding is completed
		if ( ! get_option( 'lua_onboarding_completed', false ) ) {
			wp_send_json_error( 'Onboarding not completed' );
			return;
		}
		
		// Get stored data
		$user_id = get_option( 'lua_user_id', '' );
		$organization_id = get_option( 'lua_organization_id', '' );
		$agent_id = get_option( 'lua_agent_id', '' );
		$token = get_option( 'lua_token', '' );
		
		
		// Check if we have all required data
		if ( empty( $user_id ) || empty( $organization_id ) || empty( $agent_id ) || empty( $token ) ) {
			wp_send_json_error( 'Missing required data for app fetch' );
			return;
		}
		
		// Fetch current app data
		$app_data = $this->fetch_current_app_data();
		
		if ( $app_data ) {
			wp_send_json_success( array(
				'redirectUri' => get_option( 'lua_redirect_uri', '' ),
				'appData' => $app_data
			) );
		} else {
			wp_send_json_error( 'Failed to fetch app data' );
		}
	}

	/**
	 * AJAX handler for sending OTP.
	 *
	 * @since 1.0.0
	 */
	public function ajax_send_otp() {
		check_ajax_referer( 'lua_otp_nonce', 'nonce' );
		
		$email = sanitize_email( $_POST['email'] );
		
		if ( ! is_email( $email ) ) {
			wp_send_json_error( 'Invalid email address' );
		}

		$otp_url = $this->get_auth_url() . '/otp';

		$response = wp_remote_post( $otp_url, array(
			'headers' => array(
				'Content-Type' => 'application/json',
				'accept' => 'application/json'
			),
			'body' => json_encode( array(
				'type' => 'email',
				'email' => $email
			) ),
			'timeout' => 30
		) );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( 'Network error: ' . $response->get_error_message() );
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		
		if ( $status_code === 201 ) {
			wp_send_json_success( 'OTP sent successfully' );
		} else {
			$body = wp_remote_retrieve_body( $response );
			wp_send_json_error( 'Failed to send OTP. Status: ' . $status_code );
		}
	}

	/**
	 * AJAX handler for verifying OTP.
	 *
	 * @since 1.0.0
	 */
	public function ajax_verify_otp() {
		check_ajax_referer( 'lua_otp_nonce', 'nonce' );
		
		$email = sanitize_email( $_POST['email'] );
		$otp = sanitize_text_field( $_POST['otp'] );
		
		if ( ! is_email( $email ) || empty( $otp ) ) {
			wp_send_json_error( 'Invalid email or OTP' );
		}

		$verify_url = $this->get_auth_url() . '/otp/verify';

		$response = wp_remote_post( $verify_url, array(
			'headers' => array(
				'Content-Type' => 'application/json',
				'accept' => 'application/json'
			),
			'body' => json_encode( array(
				'pin' => $otp,
				'type' => 'email',
				'email' => $email
			) ),
			'timeout' => 30
		) );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( 'Network error: ' . $response->get_error_message() );
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
		
		if ( isset( $data['signInToken'] ) ) {
			wp_send_json_success( $data );
		} else {
			wp_send_json_error( 'Invalid OTP or verification failed' );
		}
	}

	/**
	 * AJAX handler for creating account.
	 *
	 * @since 1.0.0
	 */
	public function ajax_create_account() {
		check_ajax_referer( 'lua_account_nonce', 'nonce' );
		
		$email = sanitize_email( $_POST['email'] );
		$token = sanitize_text_field( $_POST['token'] );
		
		if ( ! is_email( $email ) ) {
			wp_send_json_error( 'Invalid email address' );
		}

		// Get store information
		$store_info = $this->get_store_information();
		
		// Add WooCommerce API credentials
		$wc_credentials = $this->generate_wc_api_credentials();
		$store_info['woocommerce_api'] = $wc_credentials;
		
		// Add user information
		$store_info['userId'] = $email; // Using email as userId for now
		$store_info['accessToken'] = $token;

		// Log the data being sent

		// Send to backend
		$response = wp_remote_post( $this->get_api_url() . '/woocommerce/app', array(
			'headers' => array(
				'Content-Type' => 'application/json',
				'Accept' => 'application/json',
				'Authorization' => 'Bearer ' . $token
			),
			'body' => json_encode( $store_info ),
			'timeout' => 30
		) );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( 'Network error: ' . $response->get_error_message() );
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		
		
		if ( $status_code >= 200 && $status_code < 300 ) {
			// Parse the response to get the redirectUri
			$response_data = json_decode( $body, true );
			$lua_token = isset( $response_data['luaToken'] ) ? $response_data['luaToken'] : '';
			$agent_id = isset( $response_data['agentId'] ) ? $response_data['agentId'] : '';
			$redirect_uri = isset( $response_data['redirectUri'] ) ? $response_data['redirectUri'] : '';
			$organization_id = isset( $response_data['orgId'] ) ? $response_data['orgId'] : '';
			$user_id = isset( $response_data['userId'] ) ? $response_data['userId'] : ''; // Fixed: use 'userId' not 'id'
			
			
			// Mark onboarding as completed and store all values
			update_option( 'lua_onboarding_completed', true );
			update_option( 'lua_user_email', $email );
			update_option( 'lua_token', $lua_token );
			update_option( 'lua_agent_id', $agent_id );
			update_option( 'lua_organization_id', $organization_id );
			update_option( 'lua_user_id', $user_id );
			update_option( 'lua_redirect_uri', $redirect_uri ); // Store redirectUri for later use
			
			wp_send_json_success( array(
				'message' => 'Account created successfully',
				'redirectUri' => $redirect_uri
			) );
		} else {
			wp_send_json_error( 'Failed to create account. Status: ' . $status_code . ' Response: ' . $body );
		}
	}

	/**
	 * AJAX handler for checking REST API status.
	 *
	 * @since 1.0.0
	 */
	public function ajax_check_rest_api() {
		check_ajax_referer( 'lua_otp_nonce', 'nonce' );
		
		// Just check if WooCommerce is active and we have basic permissions
		$status = array(
			'available' => false,
			'error' => '',
			'instructions' => array(),
			'fix_url' => ''
		);

		// Check if WooCommerce is active
		if ( ! class_exists( 'WooCommerce' ) ) {
			$status['error'] = 'WooCommerce is not active';
			$status['instructions'][] = 'Please activate WooCommerce plugin first';
			wp_send_json_error( $status );
			return;
		}

		// Check if we can create API keys
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			$status['error'] = 'Insufficient permissions to create API keys';
			$status['instructions'][] = 'You need administrator privileges to create WooCommerce API keys';
			wp_send_json_error( $status );
			return;
		}

		// All basic checks passed - we'll try to create the key during account creation
		wp_send_json_success( 'Basic checks passed' );
	}

	/**
	 * Register custom REST API routes.
	 *
	 * @since 1.0.0
	 */
	public function register_rest_routes() {
		// Debug: Log that routes are being registered

		register_rest_route( 'lua/v1', '/products', array(
			'methods' => 'GET',
			'callback' => array( $this, 'get_products_endpoint' ),
			'permission_callback' => array( $this, 'validate_api_key' ),
		) );

		register_rest_route( 'lua/v1', '/orders', array(
			'methods' => 'GET',
			'callback' => array( $this, 'get_orders_endpoint' ),
			'permission_callback' => array( $this, 'validate_api_key' ),
		) );

		register_rest_route( 'lua/v1', '/customers', array(
			'methods' => 'GET',
			'callback' => array( $this, 'get_customers_endpoint' ),
			'permission_callback' => array( $this, 'validate_api_key' ),
		) );

		register_rest_route( 'lua/v1', '/store-info', array(
			'methods' => 'GET',
			'callback' => array( $this, 'get_store_info_endpoint' ),
			'permission_callback' => array( $this, 'validate_api_key' ),
		) );

		register_rest_route( 'lua/v1', '/widget-settings', array(
			'methods' => 'GET',
			'callback' => array( $this, 'get_widget_settings_endpoint' ),
			'permission_callback' => array( $this, 'validate_api_key' ),
		) );

		register_rest_route( 'lua/v1', '/widget-settings', array(
			'methods' => 'PUT',
			'callback' => array( $this, 'update_widget_settings_endpoint' ),
			'permission_callback' => array( $this, 'validate_api_key' ),
			'args' => array(
				'enabled' => array(
					'type' => 'boolean',
					'description' => 'Enable or disable the widget',
				),
				'position' => array(
					'type' => 'string',
					'enum' => array( 'bottom-right', 'bottom-left', 'top-right', 'top-left' ),
					'description' => 'Widget position on screen',
				),
				'theme' => array(
					'type' => 'string',
					'enum' => array( 'light', 'dark' ),
					'description' => 'Widget theme',
				),
				'button_text' => array(
					'type' => 'string',
					'description' => 'Button text',
				),
				'chat_title' => array(
					'type' => 'string',
					'description' => 'Chat window title',
				),
				'button_icon' => array(
					'type' => 'string',
					'description' => 'Button icon URL (can be empty to remove icon)',
				),
				'button_color' => array(
					'type' => 'string',
					'pattern' => '^#[0-9a-fA-F]{6}$',
					'description' => 'Button color in hex format',
				),
				'chat_height' => array(
					'type' => 'integer',
					'minimum' => 300,
					'maximum' => 800,
					'description' => 'Chat window height in pixels',
				),
				'chat_width' => array(
					'type' => 'integer',
					'minimum' => 300,
					'maximum' => 600,
					'description' => 'Chat window width in pixels',
				),
				'voice_enabled' => array(
					'type' => 'boolean',
					'description' => 'Enable voice mode',
				),
				'bottom_position' => array(
					'type' => 'integer',
					'minimum' => 0,
					'maximum' => 200,
					'description' => 'Bottom position in pixels',
				),
				'right_position' => array(
					'type' => 'integer',
					'minimum' => 0,
					'maximum' => 200,
					'description' => 'Right position in pixels',
				),
			),
		) );

		register_rest_route( 'lua/v1', '/checkout-link', array(
			'methods' => 'POST',
			'callback' => array( $this, 'create_checkout_link_endpoint' ),
			'permission_callback' => array( $this, 'validate_api_key' ),
			'args' => array(
				'products' => array(
					'type' => 'array',
					'required' => true,
					'description' => 'Array of products to add to cart',
					'items' => array(
						'type' => 'object',
						'properties' => array(
							'product_id' => array(
								'type' => 'integer',
								'required' => true,
								'description' => 'Product ID',
							),
							'variation_id' => array(
								'type' => 'integer',
								'description' => 'Variation ID (required for variable products)',
							),
							'quantity' => array(
								'type' => 'integer',
								'default' => 1,
								'minimum' => 1,
								'description' => 'Quantity to add',
							),
							'variation' => array(
								'type' => 'object',
								'description' => 'Variation attributes (required for variable products)',
							),
						),
					),
				),
				'customer_email' => array(
					'type' => 'string',
					'format' => 'email',
					'description' => 'Customer email for pre-filling checkout',
				),
				'return_url' => array(
					'type' => 'string',
					'format' => 'uri',
					'description' => 'URL to return to after checkout',
				),
			),
		) );

		register_rest_route( 'lua/v1', '/debug-cart', array(
			'methods' => 'GET',
			'callback' => array( $this, 'debug_cart_endpoint' ),
			'permission_callback' => array( $this, 'validate_api_key' ),
		) );

		// Debug: Log that routes have been registered
		
		// Debug: List all registered routes
		global $wp_rest_server;
		if ( $wp_rest_server ) {
			$routes = $wp_rest_server->get_routes();
			$lua_routes = array_filter( $routes, function( $key ) {
				return strpos( $key, '/lua/' ) === 0;
			}, ARRAY_FILTER_USE_KEY );
		}
	}

	/**
	 * Test endpoint to verify routes are working.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response Response object.
	 * @since 1.0.0
	 */
	public function test_endpoint( $request ) {
		return new \WP_REST_Response( array(
			'message' => 'Lua REST API is working!',
			'timestamp' => current_time( 'mysql' ),
			'plugin_version' => '1.0.0'
		), 200 );
	}

	/**
	 * Validate WooCommerce API key for custom endpoints.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return bool|WP_Error True if valid, WP_Error if invalid.
	 * @since 1.0.0
	 */
	public function validate_api_key( $request ) {
		// Get the Authorization header
		$auth_header = $request->get_header( 'Authorization' );
		
		if ( ! $auth_header ) {
			return new \WP_Error( 'no_auth', 'Authorization header required', array( 'status' => 401 ) );
		}

		// Check if it's Basic Auth format
		if ( strpos( $auth_header, 'Basic ' ) === 0 ) {
			$credentials = base64_decode( substr( $auth_header, 6 ) );
			list( $consumer_key, $consumer_secret ) = explode( ':', $credentials );
		} else {
			return new \WP_Error( 'invalid_auth', 'Invalid authorization format', array( 'status' => 401 ) );
		}

		// Validate against stored Lua API key
		$stored_key = get_option( 'lua_wc_consumer_key' );
		$stored_secret = get_option( 'lua_wc_consumer_secret' );

		if ( ! $stored_key || ! $stored_secret ) {
			return new \WP_Error( 'no_api_key', 'No API key configured', array( 'status' => 401 ) );
		}

		if ( $consumer_key !== $stored_key || $consumer_secret !== $stored_secret ) {
			return new \WP_Error( 'invalid_api_key', 'Invalid API key', array( 'status' => 401 ) );
		}

		return true;
	}

	/**
	 * Get products endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response Response object.
	 * @since 1.0.0
	 */
	public function get_products_endpoint( $request ) {
		$args = array(
			'post_type' => 'product',
			'post_status' => 'publish',
			'posts_per_page' => $request->get_param( 'per_page' ) ?: 10,
			'paged' => $request->get_param( 'page' ) ?: 1,
		);

		$products = get_posts( $args );
		$products_data = array();

		foreach ( $products as $product ) {
			$wc_product = wc_get_product( $product->ID );
			if ( $wc_product ) {
				$product_data = array(
					'id' => $wc_product->get_id(),
					'name' => $wc_product->get_name(),
					'slug' => $wc_product->get_slug(),
					'type' => $wc_product->get_type(),
					'price' => $wc_product->get_price(),
					'regular_price' => $wc_product->get_regular_price(),
					'sale_price' => $wc_product->get_sale_price(),
					'description' => $wc_product->get_description(),
					'short_description' => $wc_product->get_short_description(),
					'categories' => wp_get_post_terms( $wc_product->get_id(), 'product_cat', array( 'fields' => 'names' ) ),
					'images' => $this->get_product_images( $wc_product ),
					'stock_status' => $wc_product->get_stock_status(),
					'stock_quantity' => $wc_product->get_stock_quantity(),
					'date_created' => $wc_product->get_date_created()->format( 'Y-m-d H:i:s' ),
					'date_modified' => $wc_product->get_date_modified()->format( 'Y-m-d H:i:s' ),
				);

				// Add variations for variable products
				if ( $wc_product->is_type( 'variable' ) ) {
					$product_data['attributes'] = $this->get_product_attributes( $wc_product );
					$product_data['variations'] = $this->get_product_variations( $wc_product );
				}

				$products_data[] = $product_data;
			}
		}

		return new \WP_REST_Response( $products_data, 200 );
	}

	/**
	 * Get orders endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response Response object.
	 * @since 1.0.0
	 */
	public function get_orders_endpoint( $request ) {
		$per_page = $request->get_param( 'per_page' ) ?: 10;
		$page = $request->get_param( 'page' ) ?: 1;
		$offset = ( $page - 1 ) * $per_page;

		// HPOS-compatible order query
		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			// Use HPOS-compatible query
			$order_ids = wc_get_orders( array(
				'status' => 'any',
				'limit' => $per_page,
				'offset' => $offset,
				'return' => 'ids',
			) );
		} else {
			// Use traditional WordPress query
			$args = array(
				'post_type' => 'shop_order',
				'post_status' => 'any',
				'posts_per_page' => $per_page,
				'paged' => $page,
				'fields' => 'ids',
			);
			$order_ids = get_posts( $args );
		}

		$orders_data = array();

		foreach ( $order_ids as $order_id ) {
			$wc_order = wc_get_order( $order_id );
			if ( $wc_order ) {
				$orders_data[] = array(
					'id' => $wc_order->get_id(),
					'status' => $wc_order->get_status(),
					'total' => $wc_order->get_total(),
					'currency' => $wc_order->get_currency(),
					'customer_id' => $wc_order->get_customer_id(),
					'billing' => array(
						'first_name' => $wc_order->get_billing_first_name(),
						'last_name' => $wc_order->get_billing_last_name(),
						'email' => $wc_order->get_billing_email(),
						'phone' => $wc_order->get_billing_phone(),
					),
					'date_created' => $wc_order->get_date_created()->format( 'Y-m-d H:i:s' ),
					'date_modified' => $wc_order->get_date_modified()->format( 'Y-m-d H:i:s' ),
				);
			}
		}

		return new \WP_REST_Response( $orders_data, 200 );
	}

	/**
	 * Get customers endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response Response object.
	 * @since 1.0.0
	 */
	public function get_customers_endpoint( $request ) {
		$args = array(
			'role' => 'customer',
			'number' => $request->get_param( 'per_page' ) ?: 10,
			'paged' => $request->get_param( 'page' ) ?: 1,
		);

		$customers = get_users( $args );
		$customers_data = array();

		foreach ( $customers as $customer ) {
			$customers_data[] = array(
				'id' => $customer->ID,
				'email' => $customer->user_email,
				'first_name' => $customer->first_name,
				'last_name' => $customer->last_name,
				'date_registered' => $customer->user_registered,
				'orders_count' => wc_get_customer_order_count( $customer->ID ),
				'total_spent' => wc_get_customer_total_spent( $customer->ID ),
			);
		}

		return new \WP_REST_Response( $customers_data, 200 );
	}

	/**
	 * Get store info endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response Response object.
	 * @since 1.0.0
	 */
	public function get_store_info_endpoint( $request ) {
		$store_info = $this->get_store_information();
		return new \WP_REST_Response( $store_info, 200 );
	}

	/**
	 * Get widget settings endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response Response object.
	 * @since 1.0.0
	 */
	public function get_widget_settings_endpoint( $request ) {
		$settings = $this->get_widget_settings();
		
		// Return only the settings that can be modified via API
		$api_settings = array(
			'enabled' => (bool) $settings['enabled'],
			'position' => $settings['position'],
			'theme' => $settings['theme'],
			'button_text' => $settings['button_text'],
			'chat_title' => $settings['chat_title'],
			'button_icon' => $settings['button_icon'],
			'button_color' => $settings['button_color'],
			'chat_height' => $settings['chat_height'],
			'chat_width' => $settings['chat_width'],
			'voice_enabled' => (bool) $settings['voice_enabled'],
			'bottom_position' => $settings['bottom_position'],
			'right_position' => $settings['right_position'],
			'agent_id' => $settings['agent_id'], // Read-only, for reference
			'environment' => $settings['environment'], // Read-only, for reference
		);
		
		return new \WP_REST_Response( $api_settings, 200 );
	}

	/**
	 * Update widget settings endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response Response object.
	 * @since 1.0.0
	 */
	public function update_widget_settings_endpoint( $request ) {
		$params = $request->get_params();
		$updated_settings = array();
		$errors = array();
		
		// Validate and sanitize each parameter
		$validated_params = array();
		
		// Boolean fields
		if ( isset( $params['enabled'] ) ) {
			$validated_params['lua_widget_enabled'] = $params['enabled'] ? 1 : 0;
		}
		
		if ( isset( $params['voice_enabled'] ) ) {
			$validated_params['lua_widget_voice_enabled'] = $params['voice_enabled'] ? 1 : 0;
		}
		
		// String fields with validation
		if ( isset( $params['position'] ) ) {
			$valid_positions = array( 'bottom-right', 'bottom-left', 'top-right', 'top-left' );
			if ( in_array( $params['position'], $valid_positions, true ) ) {
				$validated_params['lua_widget_position'] = sanitize_text_field( $params['position'] );
			} else {
				$errors[] = 'Invalid position value. Must be one of: ' . implode( ', ', $valid_positions );
			}
		}
		
		if ( isset( $params['theme'] ) ) {
			$valid_themes = array( 'light', 'dark' );
			if ( in_array( $params['theme'], $valid_themes, true ) ) {
				$validated_params['lua_widget_theme'] = sanitize_text_field( $params['theme'] );
			} else {
				$errors[] = 'Invalid theme value. Must be one of: ' . implode( ', ', $valid_themes );
			}
		}
		
		if ( isset( $params['button_text'] ) ) {
			$validated_params['lua_widget_button_text'] = sanitize_text_field( $params['button_text'] );
		}
		
		if ( isset( $params['chat_title'] ) ) {
			$validated_params['lua_widget_chat_title'] = sanitize_text_field( $params['chat_title'] );
		}
		
		if ( isset( $params['button_icon'] ) ) {
			if ( empty( $params['button_icon'] ) || filter_var( $params['button_icon'], FILTER_VALIDATE_URL ) ) {
				$validated_params['lua_widget_button_icon'] = esc_url_raw( $params['button_icon'] );
			} else {
				$errors[] = 'Invalid button_icon URL format. Must be a valid URL or empty string';
			}
		}
		
		if ( isset( $params['button_color'] ) ) {
			if ( preg_match( '/^#[0-9a-fA-F]{6}$/', $params['button_color'] ) ) {
				$validated_params['lua_widget_button_color'] = sanitize_hex_color( $params['button_color'] );
			} else {
				$errors[] = 'Invalid button_color format. Must be a valid hex color (e.g., #FF0000)';
			}
		}
		
		// Integer fields with range validation
		if ( isset( $params['chat_height'] ) ) {
			$height = absint( $params['chat_height'] );
			if ( $height >= 300 && $height <= 800 ) {
				$validated_params['lua_widget_chat_height'] = $height;
			} else {
				$errors[] = 'Invalid chat_height. Must be between 300 and 800 pixels';
			}
		}
		
		if ( isset( $params['chat_width'] ) ) {
			$width = absint( $params['chat_width'] );
			if ( $width >= 300 && $width <= 600 ) {
				$validated_params['lua_widget_chat_width'] = $width;
			} else {
				$errors[] = 'Invalid chat_width. Must be between 300 and 600 pixels';
			}
		}
		
		if ( isset( $params['bottom_position'] ) ) {
			$bottom = absint( $params['bottom_position'] );
			if ( $bottom >= 0 && $bottom <= 200 ) {
				$validated_params['lua_widget_bottom_position'] = $bottom;
			} else {
				$errors[] = 'Invalid bottom_position. Must be between 0 and 200 pixels';
			}
		}
		
		if ( isset( $params['right_position'] ) ) {
			$right = absint( $params['right_position'] );
			if ( $right >= 0 && $right <= 200 ) {
				$validated_params['lua_widget_right_position'] = $right;
			} else {
				$errors[] = 'Invalid right_position. Must be between 0 and 200 pixels';
			}
		}
		
		// Return errors if any validation failed
		if ( ! empty( $errors ) ) {
			return new \WP_REST_Response( array(
				'error' => 'Validation failed',
				'messages' => $errors
			), 400 );
		}
		
		// Update settings
		foreach ( $validated_params as $key => $value ) {
			update_option( $key, $value );
			$updated_settings[ str_replace( 'lua_widget_', '', $key ) ] = $value;
		}
		
		// Get updated settings to return
		$current_settings = $this->get_widget_settings();
		
		return new \WP_REST_Response( array(
			'message' => 'Widget settings updated successfully',
			'updated_fields' => array_keys( $updated_settings ),
			'current_settings' => array(
				'enabled' => (bool) $current_settings['enabled'],
				'position' => $current_settings['position'],
				'theme' => $current_settings['theme'],
				'button_text' => $current_settings['button_text'],
				'chat_title' => $current_settings['chat_title'],
				'button_icon' => $current_settings['button_icon'],
				'button_color' => $current_settings['button_color'],
				'chat_height' => $current_settings['chat_height'],
				'chat_width' => $current_settings['chat_width'],
				'voice_enabled' => (bool) $current_settings['voice_enabled'],
				'bottom_position' => $current_settings['bottom_position'],
				'right_position' => $current_settings['right_position'],
			)
		), 200 );
	}

	/**
	 * Create checkout link endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response Response object.
	 * @since 1.0.0
	 */
	public function create_checkout_link_endpoint( $request ) {
		$params = $request->get_params();
		$products = $params['products'] ?? array();
		$customer_email = $params['customer_email'] ?? '';
		$return_url = $params['return_url'] ?? '';

		// Validate products array
		if ( empty( $products ) || ! is_array( $products ) ) {
			return new \WP_REST_Response( array(
				'error' => 'Invalid products data',
				'message' => 'Products array is required and must not be empty'
			), 400 );
		}

		// Validate each product
		$validation_result = $this->validate_checkout_products( $products );
		if ( $validation_result['error'] ) {
			return new \WP_REST_Response( $validation_result, 400 );
		}

		// Create checkout link
		$checkout_result = $this->create_checkout_link( $products, $customer_email, $return_url );
		
		if ( $checkout_result['success'] ) {
			return new \WP_REST_Response( array(
				'success' => true,
				'checkout_url' => $checkout_result['checkout_url'],
				'cart_total' => $checkout_result['cart_total'],
				'products_added' => $checkout_result['products_added'],
				'message' => 'Checkout link created successfully'
			), 200 );
		} else {
			return new \WP_REST_Response( array(
				'error' => 'Failed to create checkout link',
				'message' => $checkout_result['message']
			), 500 );
		}
	}

	/**
	 * Validate products for checkout link creation.
	 *
	 * @param array $products Products array.
	 * @return array Validation result.
	 * @since 1.0.0
	 */
	private function validate_checkout_products( $products ) {
		foreach ( $products as $index => $product ) {
			// Check required fields
			if ( ! isset( $product['product_id'] ) || ! is_numeric( $product['product_id'] ) ) {
				return array(
					'error' => true,
					'message' => "Product at index {$index} is missing or invalid product_id"
				);
			}

			$product_id = intval( $product['product_id'] );
			$wc_product = wc_get_product( $product_id );

			if ( ! $wc_product ) {
				return array(
					'error' => true,
					'message' => "Product with ID {$product_id} not found"
				);
			}

			// Check if product is purchasable
			if ( ! $wc_product->is_purchasable() ) {
				return array(
					'error' => true,
					'message' => "Product '{$wc_product->get_name()}' is not purchasable"
				);
			}

			// For variable products, check variation
			if ( $wc_product->is_type( 'variable' ) ) {
				if ( ! isset( $product['variation_id'] ) || ! is_numeric( $product['variation_id'] ) ) {
					return array(
						'error' => true,
						'message' => "Variable product '{$wc_product->get_name()}' requires variation_id"
					);
				}

				$variation_id = intval( $product['variation_id'] );
				$variation = wc_get_product( $variation_id );

				if ( ! $variation || ! $variation->is_type( 'variation' ) ) {
					return array(
						'error' => true,
						'message' => "Variation with ID {$variation_id} not found"
					);
				}

				// Check if variation belongs to the product
				if ( $variation->get_parent_id() !== $product_id ) {
					return array(
						'error' => true,
						'message' => "Variation {$variation_id} does not belong to product {$product_id}"
					);
				}

				// Check if variation is purchasable
				if ( ! $variation->is_purchasable() ) {
					return array(
						'error' => true,
						'message' => "Variation '{$variation->get_name()}' is not purchasable"
					);
				}
			}

			// Check quantity
			$quantity = isset( $product['quantity'] ) ? intval( $product['quantity'] ) : 1;
			if ( $quantity < 1 ) {
				return array(
					'error' => true,
					'message' => "Invalid quantity for product '{$wc_product->get_name()}'"
				);
			}
		}

		return array( 'error' => false );
	}

	/**
	 * Create checkout link with products.
	 *
	 * @param array $products Products to add.
	 * @param string $customer_email Customer email.
	 * @param string $return_url Return URL.
	 * @return array Result with checkout URL.
	 * @since 1.0.0
	 */
	private function create_checkout_link( $products, $customer_email = '', $return_url = '' ) {
		try {
			// Generate unique cart key
			$cart_key = 'lua_checkout_' . time() . '_' . wp_generate_password( 8, false );
			
			// Create cart data
			$cart_data = array();
			$products_added = array();
			$cart_total = 0;

			foreach ( $products as $product ) {
				$product_id = intval( $product['product_id'] );
				$quantity = intval( $product['quantity'] ?? 1 );
				$variation_id = isset( $product['variation_id'] ) ? intval( $product['variation_id'] ) : 0;
				$variation_attributes = $product['variation'] ?? array();

				$wc_product = wc_get_product( $product_id );
				
				if ( $wc_product->is_type( 'variable' ) && $variation_id ) {
					$variation = wc_get_product( $variation_id );
					$cart_total += $variation->get_price() * $quantity;
					
					$products_added[] = array(
						'product_id' => $product_id,
						'variation_id' => $variation_id,
						'name' => $variation->get_name(),
						'quantity' => $quantity,
						'price' => $variation->get_price(),
						'total' => $variation->get_price() * $quantity
					);
				} else {
					$cart_total += $wc_product->get_price() * $quantity;
					
					$products_added[] = array(
						'product_id' => $product_id,
						'name' => $wc_product->get_name(),
						'quantity' => $quantity,
						'price' => $wc_product->get_price(),
						'total' => $wc_product->get_price() * $quantity
					);
				}

				$cart_data[] = array(
					'product_id' => $product_id,
					'variation_id' => $variation_id,
					'quantity' => $quantity,
					'variation' => $variation_attributes
				);
			}

			// Store cart data temporarily
			set_transient( $cart_key, $cart_data, HOUR_IN_SECONDS );

			// Build checkout URL
			$checkout_url = add_query_arg( array(
				'lua_cart' => $cart_key,
				'lua_email' => $customer_email,
				'lua_return' => $return_url
			), wc_get_checkout_url() );

			return array(
				'success' => true,
				'checkout_url' => $checkout_url,
				'cart_total' => $cart_total,
				'products_added' => $products_added,
				'cart_key' => $cart_key
			);

		} catch ( Exception $e ) {
			return array(
				'success' => false,
				'message' => 'Failed to create checkout link: ' . $e->getMessage()
			);
		}
	}

	/**
	 * Handle Lua checkout cart loading.
	 *
	 * @since 1.0.0
	 */
	public function handle_lua_checkout_cart() {
		// Check if this is a Lua checkout request
		if ( ! isset( $_GET['lua_cart'] ) ) {
			return;
		}

		// Prevent multiple executions
		static $cart_loaded = false;
		if ( $cart_loaded ) {
			return;
		}

		// Ensure we're not running too early - check if wp_loaded has fired
		if ( ! did_action( 'wp_loaded' ) ) {
			return;
		}

		$cart_key = sanitize_text_field( $_GET['lua_cart'] );
		$cart_data = get_transient( $cart_key );

		// Debug logging

		if ( ! $cart_data ) {
			wc_add_notice( 'Checkout link has expired. Please try again.', 'error' );
			return;
		}

		// Ensure WooCommerce is loaded
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}

		// Clear existing cart
		WC()->cart->empty_cart();

		$products_added = 0;
		$errors = array();

		// Add products to cart
		foreach ( $cart_data as $item ) {
			$product_id = intval( $item['product_id'] );
			$quantity = intval( $item['quantity'] );
			$variation_id = isset( $item['variation_id'] ) ? intval( $item['variation_id'] ) : 0;
			$variation_attributes = $item['variation'] ?? array();


			$cart_item_key = false;

			if ( $variation_id ) {
				// Add variation to cart
				$cart_item_key = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation_attributes );
			} else {
				// Add simple product to cart
				$cart_item_key = WC()->cart->add_to_cart( $product_id, $quantity );
			}

			if ( $cart_item_key ) {
				$products_added++;
			} else {
				$errors[] = "Failed to add product ID {$product_id} to cart";
			}
		}

		// Pre-fill customer email if provided
		if ( isset( $_GET['lua_email'] ) && ! empty( $_GET['lua_email'] ) ) {
			$email = sanitize_email( $_GET['lua_email'] );
			if ( is_email( $email ) ) {
				// Set billing email in session
				WC()->session->set( 'billing_email', $email );
			}
		}

		// Set return URL if provided
		if ( isset( $_GET['lua_return'] ) && ! empty( $_GET['lua_return'] ) ) {
			$return_url = esc_url_raw( $_GET['lua_return'] );
			WC()->session->set( 'lua_return_url', $return_url );
		}

		// Clean up the transient
		delete_transient( $cart_key );

		// Add notices
		if ( $products_added > 0 ) {
			wc_add_notice( "Successfully added {$products_added} product(s) to your cart. Please complete your checkout.", 'success' );
		}

		if ( ! empty( $errors ) ) {
			foreach ( $errors as $error ) {
				wc_add_notice( $error, 'error' );
			}
		}

		// Mark as loaded to prevent multiple executions
		$cart_loaded = true;

		// Force cart recalculation
		WC()->cart->calculate_totals();
	}

	/**
	 * Debug cart endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response Response object.
	 * @since 1.0.0
	 */
	public function debug_cart_endpoint( $request ) {
		$debug_info = array(
			'woocommerce_loaded' => function_exists( 'WC' ),
			'cart_available' => function_exists( 'WC' ) && WC()->cart ? true : false,
			'current_cart_contents' => array(),
			'cart_total' => 0,
			'cart_count' => 0,
			'session_data' => array(),
			'url_params' => $_GET,
		);

		if ( function_exists( 'WC' ) && WC()->cart ) {
			$debug_info['cart_total'] = WC()->cart->get_cart_total();
			$debug_info['cart_count'] = WC()->cart->get_cart_contents_count();
			
			foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
				$debug_info['current_cart_contents'][] = array(
					'key' => $cart_item_key,
					'product_id' => $cart_item['product_id'],
					'variation_id' => $cart_item['variation_id'],
					'quantity' => $cart_item['quantity'],
					'data' => $cart_item['data']->get_name(),
				);
			}

			if ( WC()->session ) {
				$debug_info['session_data'] = array(
					'billing_email' => WC()->session->get( 'billing_email' ),
					'lua_return_url' => WC()->session->get( 'lua_return_url' ),
					'cart_hash' => WC()->session->get( 'cart_hash' ),
				);
			}
		}

		return new \WP_REST_Response( $debug_info, 200 );
	}

	/**
	 * Generate WooCommerce API credentials for server access.
	 *
	 * @return array WooCommerce API credentials.
	 * @since 1.0.0
	 */
	private function generate_wc_api_credentials() {
		// Get or create API key for Lua server
		$consumer_key = get_option( 'lua_wc_consumer_key' );
		$consumer_secret = get_option( 'lua_wc_consumer_secret' );

		if ( ! $consumer_key || ! $consumer_secret ) {
			// Generate new API credentials
			$credentials = $this->create_wc_api_key();
			
			if ( $credentials ) {
				$consumer_key = $credentials['consumer_key'];
				$consumer_secret = $credentials['consumer_secret'];
				
				// Store credentials for future use
				update_option( 'lua_wc_consumer_key', $consumer_key );
				update_option( 'lua_wc_consumer_secret', $consumer_secret );
			} else {
				return array(
					'error' => 'Failed to create WooCommerce API key',
					'instructions' => array( 
						'Please go to WooCommerce → Settings → Advanced → API Keys',
						'Create a new API key with "Read/Write" permissions',
						'Then try the onboarding process again'
					),
					'fix_url' => admin_url( 'admin.php?page=wc-settings&tab=advanced&section=keys' )
				);
			}
		}

		return array(
			'store_url' => get_site_url(),
			'consumer_key' => $consumer_key,
			'consumer_secret' => $consumer_secret,
			'api_version' => 'wc/v3',
			'permissions' => 'read_write'
		);
	}

	/**
	 * Get store information.
	 *
	 * @return array Store information.
	 * @since 1.0.0
	 */
	private function get_store_information() {
		// Get all available bloginfo fields
		$bloginfo_fields = array(
			'name', 'description', 'wpurl', 'url', 'admin_email', 'charset', 
			'version', 'html_type', 'text_direction', 'language', 'stylesheet_url', 
			'stylesheet_directory', 'template_url', 'template_directory', 'pingback_url', 
			'atom_url', 'rdf_url', 'rss_url', 'rss2_url', 'comments_atom_url', 'comments_rss2_url'
		);
		
		$bloginfo_data = array();
		foreach ( $bloginfo_fields as $field ) {
			$bloginfo_data[ 'bloginfo_' . $field ] = get_bloginfo( $field );
		}
		
		$store_info = array(
			// Core store information
			'store_name' => get_bloginfo( 'name' ),
			'store_url' => get_site_url(),
			'store_description' => get_bloginfo( 'description' ),
			'store_email' => get_option( 'admin_email' ),
			'store_currency' => get_option( 'woocommerce_currency', 'USD' ),
			'store_timezone' => get_option( 'timezone_string', 'UTC' ),
			'store_language' => get_option( 'WPLANG', 'en_US' ),
			'woocommerce_version' => WC()->version,
			'wordpress_version' => get_bloginfo( 'version' ),
			'plugin_version' => '1.0.0',
			'products_count' => wp_count_posts( 'product' )->publish,
			'orders_count' => $this->get_orders_count(),
			'customers_count' => count_users()['total_users'],
			'categories' => $this->get_product_categories(),
			'payment_methods' => $this->get_payment_methods(),
			'shipping_methods' => $this->get_shipping_methods(),
			'store_settings' => array(
				'weight_unit' => get_option( 'woocommerce_weight_unit' ),
				'dimension_unit' => get_option( 'woocommerce_dimension_unit' ),
				'price_decimal_separator' => get_option( 'woocommerce_price_decimal_sep' ),
				'price_thousand_separator' => get_option( 'woocommerce_price_thousand_sep' ),
				'price_num_decimals' => get_option( 'woocommerce_price_num_decimals' ),
			),
			// All bloginfo fields
			'bloginfo' => $bloginfo_data,
			// Additional WordPress site information
			'site_info' => array(
				'site_url' => get_site_url(),
				'home_url' => get_home_url(),
				'admin_url' => admin_url(),
				'wp_upload_dir' => wp_upload_dir(),
				'active_theme' => wp_get_theme()->get('Name'),
				'active_theme_version' => wp_get_theme()->get('Version'),
				'active_theme_author' => wp_get_theme()->get('Author'),
				'active_theme_description' => wp_get_theme()->get('Description'),
				'active_plugins' => get_option( 'active_plugins', array() ),
				'multisite' => is_multisite(),
				'is_ssl' => is_ssl(),
				'wp_debug' => defined( 'WP_DEBUG' ) && WP_DEBUG,
				'wp_debug_log' => defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG,
				'wp_debug_display' => defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY,
				'script_debug' => defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG,
				'memory_limit' => ini_get( 'memory_limit' ),
				'max_execution_time' => ini_get( 'max_execution_time' ),
				'upload_max_filesize' => ini_get( 'upload_max_filesize' ),
				'post_max_size' => ini_get( 'post_max_size' ),
				'max_input_vars' => ini_get( 'max_input_vars' ),
				'php_version' => PHP_VERSION,
				'mysql_version' => $GLOBALS['wpdb']->db_version(),
				'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
			)
		);

		return $store_info;
	}

	/**
	 * Get product categories.
	 *
	 * @return array Product categories.
	 * @since 1.0.0
	 */
	private function get_product_categories() {
		$categories = get_terms( array(
			'taxonomy' => 'product_cat',
			'hide_empty' => false,
		) );

		$category_data = array();
		foreach ( $categories as $category ) {
			$category_data[] = array(
				'id' => $category->term_id,
				'name' => $category->name,
				'slug' => $category->slug,
				'count' => $category->count,
			);
		}

		return $category_data;
	}

	/**
	 * Get payment methods.
	 *
	 * @return array Payment methods.
	 * @since 1.0.0
	 */
	private function get_payment_methods() {
		$payment_gateways = WC()->payment_gateways()->payment_gateways();
		$methods = array();

		foreach ( $payment_gateways as $gateway ) {
			if ( $gateway->enabled === 'yes' ) {
				$methods[] = array(
					'id' => $gateway->id,
					'title' => $gateway->title,
					'description' => $gateway->description,
				);
			}
		}

		return $methods;
	}

	/**
	 * Get shipping methods.
	 *
	 * @return array Shipping methods.
	 * @since 1.0.0
	 */
	private function get_shipping_methods() {
		$methods = array();
		
		try {
			if ( class_exists( '\WC_Shipping_Zones' ) ) {
				$shipping_zones = \WC_Shipping_Zones::get_zones();
				
				foreach ( $shipping_zones as $zone ) {
					$zone_methods = $zone['shipping_methods'];
					foreach ( $zone_methods as $method ) {
						if ( $method->is_enabled() ) {
							$methods[] = array(
								'id' => $method->id,
								'title' => $method->title,
								'zone_name' => $zone['zone_name'],
							);
						}
					}
				}
			}
		} catch ( Exception $e ) {
		}

		return $methods;
	}

	/**
	 * Demo products page.
	 *
	 * @since 1.0.0
	 */
	public function demo_products_page() {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Demo Products', 'lua_shopping_assistant' ); ?></h1>
			
			<?php if ( isset( $_GET['demo_products_added'] ) ) : ?>
				<div class="notice notice-success">
					<p><?php esc_html_e( 'Demo products have been successfully added to your store!', 'lua_shopping_assistant' ); ?></p>
				</div>
			<?php endif; ?>

			<?php if ( isset( $_GET['onboarding_reset'] ) ) : ?>
				<div class="notice notice-success">
					<p><?php esc_html_e( 'Onboarding has been reset successfully!', 'lua_shopping_assistant' ); ?></p>
				</div>
			<?php endif; ?>

			<div class="card">
				<h2><?php esc_html_e( 'Add Demo Products', 'lua_shopping_assistant' ); ?></h2>
				<p><?php esc_html_e( 'This will add sample products to your WooCommerce store for testing purposes.', 'lua_shopping_assistant' ); ?></p>
				
				<form method="post" action="">
					<?php wp_nonce_field( 'lua_demo_products_action', 'lua_demo_products_nonce' ); ?>
					<input type="submit" name="lua_add_demo_products" class="button button-primary" value="<?php esc_attr_e( 'Add Demo Products', 'lua_shopping_assistant' ); ?>">
				</form>
			</div>

			<div class="card">
				<h2><?php esc_html_e( 'Reset Onboarding', 'lua_shopping_assistant' ); ?></h2>
				<p><?php esc_html_e( 'This will reset the onboarding process, allowing you to go through the setup again.', 'lua_shopping_assistant' ); ?></p>
				
				<form method="post" action="">
					<?php wp_nonce_field( 'lua_reset_onboarding_action', 'lua_reset_onboarding_nonce' ); ?>
					<input type="submit" name="lua_reset_onboarding" class="button button-secondary" value="<?php esc_attr_e( 'Reset Onboarding', 'lua_shopping_assistant' ); ?>" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to reset the onboarding? This will clear your authentication data.', 'lua_shopping_assistant' ); ?>')">
				</form>
			</div>

			<div class="card">
				<h2><?php esc_html_e( 'Demo Products List', 'lua_shopping_assistant' ); ?></h2>
				<p><?php esc_html_e( 'The following products will be created:', 'lua_shopping_assistant' ); ?></p>
				<ul>
					<li><?php esc_html_e( 'Premium Coffee Beans (Variable Product)', 'lua_shopping_assistant' ); ?>
						<ul>
							<li><?php esc_html_e( '1kg - $24.99', 'lua_shopping_assistant' ); ?></li>
							<li><?php esc_html_e( '5kg - $99.99', 'lua_shopping_assistant' ); ?></li>
							<li><?php esc_html_e( '10kg - $189.99', 'lua_shopping_assistant' ); ?></li>
						</ul>
					</li>
					<li><?php esc_html_e( 'Wireless Bluetooth Headphones - $89.99', 'lua_shopping_assistant' ); ?></li>
					<li><?php esc_html_e( 'Organic Cotton T-Shirt - $29.99', 'lua_shopping_assistant' ); ?></li>
					<li><?php esc_html_e( 'Smart Fitness Watch - $199.99', 'lua_shopping_assistant' ); ?></li>
					<li><?php esc_html_e( 'Handcrafted Wooden Bowl - $45.99', 'lua_shopping_assistant' ); ?></li>
				</ul>
			</div>
		</div>
		<?php
	}

	/**
	 * Create demo products.
	 *
	 * @since 1.0.0
	 */
	private function create_demo_products() {
		$demo_products = array(
			array(
				'name'        => 'Premium Coffee Beans',
				'description' => 'High-quality Arabica coffee beans sourced from the finest regions. Perfect for coffee enthusiasts who appreciate rich flavor and smooth finish.',
				'price'       => 24.99,
				'image_url'   => 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400&h=400&fit=crop',
				'category'    => 'Food & Beverages',
				'type'        => 'variable',
				'variations'  => array(
					array(
						'weight' => '1kg',
						'price'  => 24.99
					),
					array(
						'weight' => '5kg',
						'price'  => 99.99
					),
					array(
						'weight' => '10kg',
						'price'  => 189.99
					)
				)
			),
			array(
				'name'        => 'Wireless Bluetooth Headphones',
				'description' => 'Premium wireless headphones with noise cancellation technology. Features 30-hour battery life and crystal-clear sound quality.',
				'price'       => 89.99,
				'image_url'   => 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop',
				'category'    => 'Electronics'
			),
			array(
				'name'        => 'Organic Cotton T-Shirt',
				'description' => 'Comfortable and sustainable organic cotton t-shirt. Available in multiple colors and sizes. Perfect for everyday wear.',
				'price'       => 29.99,
				'image_url'   => 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop',
				'category'    => 'Clothing'
			),
			array(
				'name'        => 'Smart Fitness Watch',
				'description' => 'Advanced fitness tracking watch with heart rate monitor, GPS, and sleep tracking. Water-resistant and compatible with all major fitness apps.',
				'price'       => 199.99,
				'image_url'   => 'https://images.unsplash.com/photo-1544117519-31a4b719223d?w=400&h=400&fit=crop',
				'category'    => 'Electronics'
			),
			array(
				'name'        => 'Handcrafted Wooden Bowl',
				'description' => 'Beautiful handcrafted wooden bowl made from sustainable maple wood. Perfect for serving, decoration, or as a unique gift.',
				'price'       => 45.99,
				'image_url'   => 'https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=400&h=400&fit=crop',
				'category'    => 'Home & Garden'
			)
		);

		foreach ( $demo_products as $product_data ) {
			$this->create_single_product( $product_data );
		}
	}

	/**
	 * Create a single product.
	 *
	 * @param array $product_data Product data.
	 * @since 1.0.0
	 */
	private function create_single_product( $product_data ) {
		// Create or get category
		$category_id = $this->get_or_create_category( $product_data['category'] );

		// Check if this is a variable product
		if ( isset( $product_data['type'] ) && $product_data['type'] === 'variable' && isset( $product_data['variations'] ) ) {
			$this->create_variable_product( $product_data, $category_id );
		} else {
			// Create simple product
			$product = new \WC_Product_Simple();
			$product->set_name( $product_data['name'] );
			$product->set_description( $product_data['description'] );
			$product->set_regular_price( $product_data['price'] );
			$product->set_status( 'publish' );
			$product->set_catalog_visibility( 'visible' );
			$product->set_category_ids( array( $category_id ) );

			// Set product image
			$image_id = $this->set_product_image( $product_data['image_url'], $product_data['name'] );
			if ( $image_id ) {
				$product->set_image_id( $image_id );
			}

			$product->save();
		}
	}

	/**
	 * Create a variable product with variations.
	 *
	 * @param array $product_data Product data.
	 * @param int $category_id Category ID.
	 * @since 1.0.0
	 */
	private function create_variable_product( $product_data, $category_id ) {
		// Create variable product
		$product = new \WC_Product_Variable();
		$product->set_name( $product_data['name'] );
		$product->set_description( $product_data['description'] );
		$product->set_status( 'publish' );
		$product->set_catalog_visibility( 'visible' );
		$product->set_category_ids( array( $category_id ) );

		// Set product image
		$image_id = $this->set_product_image( $product_data['image_url'], $product_data['name'] );
		if ( $image_id ) {
			$product->set_image_id( $image_id );
		}

		// Create or get weight attribute
		$weight_attribute = $this->get_or_create_weight_attribute();

		// Set attributes for the variable product
		$attributes = array();
		$attributes[ $weight_attribute['id'] ] = array(
			'name' => $weight_attribute['name'],
			'value' => '',
			'position' => 0,
			'is_visible' => 1,
			'is_variation' => 1,
			'is_taxonomy' => 1
		);
		$product->set_attributes( $attributes );

		$product->save();

		// Create variations
		foreach ( $product_data['variations'] as $variation_data ) {
			$this->create_product_variation( $product->get_id(), $variation_data, $weight_attribute );
		}
	}

	/**
	 * Create a product variation.
	 *
	 * @param int $product_id Parent product ID.
	 * @param array $variation_data Variation data.
	 * @param array $weight_attribute Weight attribute data.
	 * @since 1.0.0
	 */
	private function create_product_variation( $product_id, $variation_data, $weight_attribute ) {
		$variation = new \WC_Product_Variation();
		$variation->set_parent_id( $product_id );
		$variation->set_regular_price( $variation_data['price'] );
		$variation->set_status( 'publish' );

		// Set weight attribute term
		$weight_term = $this->get_or_create_weight_term( $variation_data['weight'], $weight_attribute['id'] );
		$variation->set_attributes( array( 'pa_' . $weight_attribute['slug'] => $weight_term ) );

		$variation->save();
	}

	/**
	 * Get or create weight attribute.
	 *
	 * @return array Weight attribute data.
	 * @since 1.0.0
	 */
	private function get_or_create_weight_attribute() {
		$attribute_name = 'Weight';
		$attribute_slug = 'weight';

		// Check if WooCommerce functions are available
		if ( ! function_exists( 'wc_get_attribute_taxonomy' ) ) {
			// Fallback: create attribute using direct database operations
			return $this->create_weight_attribute_fallback( $attribute_name, $attribute_slug );
		}

		// Check if attribute already exists
		$existing_attribute = wc_get_attribute_taxonomy( $attribute_slug );
		
		if ( $existing_attribute ) {
			return array(
				'id' => $existing_attribute->attribute_id,
				'name' => $existing_attribute->attribute_label,
				'slug' => $existing_attribute->attribute_name
			);
		}

		// Create new attribute
		$attribute_id = wc_create_attribute( array(
			'name' => $attribute_name,
			'slug' => $attribute_slug,
			'type' => 'select',
			'order_by' => 'menu_order',
			'has_archives' => false
		) );

		// Register the taxonomy
		$taxonomy_name = wc_attribute_taxonomy_name( $attribute_slug );
		register_taxonomy( $taxonomy_name, 'product' );

		return array(
			'id' => $attribute_id,
			'name' => $attribute_name,
			'slug' => $attribute_slug
		);
	}

	/**
	 * Fallback method to create weight attribute using direct database operations.
	 *
	 * @param string $attribute_name Attribute name.
	 * @param string $attribute_slug Attribute slug.
	 * @return array Weight attribute data.
	 * @since 1.0.0
	 */
	private function create_weight_attribute_fallback( $attribute_name, $attribute_slug ) {
		global $wpdb;

		// Check if attribute already exists in database
		$existing_attribute = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}woocommerce_attribute_taxonomies WHERE attribute_name = %s",
			$attribute_slug
		) );

		if ( $existing_attribute ) {
			return array(
				'id' => $existing_attribute->attribute_id,
				'name' => $existing_attribute->attribute_label,
				'slug' => $existing_attribute->attribute_name
			);
		}

		// Create new attribute in database
		$result = $wpdb->insert(
			$wpdb->prefix . 'woocommerce_attribute_taxonomies',
			array(
				'attribute_name' => $attribute_slug,
				'attribute_label' => $attribute_name,
				'attribute_type' => 'select',
				'attribute_orderby' => 'menu_order',
				'attribute_public' => 0
			),
			array( '%s', '%s', '%s', '%s', '%d' )
		);

		if ( $result === false ) {
			return array(
				'id' => 0,
				'name' => $attribute_name,
				'slug' => $attribute_slug
			);
		}

		$attribute_id = $wpdb->insert_id;

		// Register the taxonomy
		$taxonomy_name = 'pa_' . $attribute_slug;
		register_taxonomy( $taxonomy_name, 'product' );

		// Clear WooCommerce cache
		if ( function_exists( 'wc_delete_product_transients' ) ) {
			wc_delete_product_transients();
		}

		return array(
			'id' => $attribute_id,
			'name' => $attribute_name,
			'slug' => $attribute_slug
		);
	}

	/**
	 * Get or create weight term.
	 *
	 * @param string $weight_value Weight value (e.g., '1kg').
	 * @param int $attribute_id Attribute ID.
	 * @return string Term slug.
	 * @since 1.0.0
	 */
	private function get_or_create_weight_term( $weight_value, $attribute_id ) {
		$term_slug = sanitize_title( $weight_value );

		// Determine taxonomy name
		if ( function_exists( 'wc_attribute_taxonomy_name_by_id' ) ) {
			$attribute_slug = wc_attribute_taxonomy_name_by_id( $attribute_id );
		} else {
			// Fallback: construct taxonomy name manually
			$attribute_slug = 'pa_weight';
		}

		// Check if term exists
		$existing_term = get_term_by( 'slug', $term_slug, $attribute_slug );
		
		if ( $existing_term ) {
			return $term_slug;
		}

		// Create new term
		$term = wp_insert_term( $weight_value, $attribute_slug, array(
			'slug' => $term_slug
		) );

		// Handle term creation errors
		if ( is_wp_error( $term ) ) {
			return $term_slug;
		}

		return $term_slug;
	}

	/**
	 * Get or create category.
	 *
	 * @param string $category_name Category name.
	 * @return int Category ID.
	 * @since 1.0.0
	 */
	private function get_or_create_category( $category_name ) {
		$category = get_term_by( 'name', $category_name, 'product_cat' );
		
		if ( ! $category ) {
			$category = wp_insert_term( $category_name, 'product_cat' );
			return $category['term_id'];
		}
		
		return $category->term_id;
	}

	/**
	 * Set product image from URL.
	 *
	 * @param string $image_url Image URL.
	 * @param string $product_name Product name for alt text.
	 * @return int|false Image ID or false on failure.
	 * @since 1.0.0
	 */
	private function set_product_image( $image_url, $product_name ) {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$upload = media_sideload_image( $image_url, 0, $product_name, 'id' );
		
		if ( is_wp_error( $upload ) ) {
			return false;
		}
		
		return $upload;
	}

	/**
	 * Create a new WooCommerce API key.
	 *
	 * @return array|false API credentials or false on failure.
	 * @since 1.0.0
	 */
	private function create_wc_api_key() {
		// Check if we can create API keys
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return false;
		}

		// Generate API credentials using WooCommerce's built-in method
		$consumer_key = 'ck_' . wp_generate_password( 32, false );
		$consumer_secret = 'cs_' . wp_generate_password( 32, false );
		
		// Create the API key in WooCommerce
		$api_key_data = array(
			'description' => 'Lua Shopping Assistant - ' . date( 'Y-m-d H:i:s' ),
			'permissions' => 'read_write',
			'user_id' => get_current_user_id(),
			'consumer_key' => $consumer_key,
			'consumer_secret' => $consumer_secret,
			'truncated_key' => substr( $consumer_key, -7 )
		);

		// Insert into wp_woocommerce_api_keys table
		global $wpdb;
		$table_name = $wpdb->prefix . 'woocommerce_api_keys';
		
		$result = $wpdb->insert(
			$table_name,
			array(
				'user_id' => get_current_user_id(),
				'description' => $api_key_data['description'],
				'permissions' => $api_key_data['permissions'],
				'consumer_key' => wc_api_hash( $consumer_key ),
				'consumer_secret' => $consumer_secret,
				'truncated_key' => $api_key_data['truncated_key'],
				'last_access' => current_time( 'mysql' )
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( $result === false ) {
			return false;
		}

		return array(
			'consumer_key' => $consumer_key,
			'consumer_secret' => $consumer_secret
		);
	}

	/**
	 * Get product images.
	 *
	 * @param WC_Product $product Product object.
	 * @return array Product images.
	 * @since 1.0.0
	 */
	private function get_product_images( $product ) {
		$images = array();
		
		// Main product image
		$main_image_id = $product->get_image_id();
		if ( $main_image_id ) {
			$main_image = wp_get_attachment_image_src( $main_image_id, 'full' );
			$images[] = array(
				'id' => $main_image_id,
				'src' => $main_image[0],
				'name' => get_the_title( $main_image_id ),
				'alt' => get_post_meta( $main_image_id, '_wp_attachment_image_alt', true ),
			);
		}

		// Gallery images
		$gallery_image_ids = $product->get_gallery_image_ids();
		foreach ( $gallery_image_ids as $image_id ) {
			$image = wp_get_attachment_image_src( $image_id, 'full' );
			$images[] = array(
				'id' => $image_id,
				'src' => $image[0],
				'name' => get_the_title( $image_id ),
				'alt' => get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
			);
		}

		return $images;
	}

	/**
	 * Get product attributes for variable products.
	 *
	 * @param WC_Product_Variable $product Variable product object.
	 * @return array Product attributes.
	 * @since 1.0.0
	 */
	private function get_product_attributes( $product ) {
		$attributes = array();
		$product_attributes = $product->get_attributes();

		foreach ( $product_attributes as $attribute ) {
			$attribute_data = array(
				'id' => $attribute->get_id(),
				'name' => $attribute->get_name(),
				'position' => $attribute->get_position(),
				'visible' => $attribute->get_visible(),
				'variation' => $attribute->get_variation(),
			);

			// Get attribute options/terms
			if ( $attribute->is_taxonomy() ) {
				$terms = wp_get_post_terms( $product->get_id(), $attribute->get_name(), array( 'fields' => 'all' ) );
				$attribute_data['options'] = array();
				foreach ( $terms as $term ) {
					$attribute_data['options'][] = array(
						'id' => $term->term_id,
						'name' => $term->name,
						'slug' => $term->slug,
					);
				}
			} else {
				// For custom attributes (non-taxonomy)
				$options = $attribute->get_options();
				$attribute_data['options'] = array();
				foreach ( $options as $option ) {
					$attribute_data['options'][] = array(
						'name' => $option,
						'slug' => sanitize_title( $option ),
					);
				}
			}

			$attributes[] = $attribute_data;
		}

		return $attributes;
	}

	/**
	 * Get product variations for variable products.
	 *
	 * @param WC_Product_Variable $product Variable product object.
	 * @return array Product variations.
	 * @since 1.0.0
	 */
	private function get_product_variations( $product ) {
		$variations = array();
		$variation_ids = $product->get_children();

		foreach ( $variation_ids as $variation_id ) {
			$variation = wc_get_product( $variation_id );
			if ( $variation && $variation->is_type( 'variation' ) ) {
				$variation_data = array(
					'id' => $variation->get_id(),
					'name' => $variation->get_name(),
					'price' => $variation->get_price(),
					'regular_price' => $variation->get_regular_price(),
					'sale_price' => $variation->get_sale_price(),
					'stock_status' => $variation->get_stock_status(),
					'stock_quantity' => $variation->get_stock_quantity(),
					'weight' => $variation->get_weight(),
					'length' => $variation->get_length(),
					'width' => $variation->get_width(),
					'height' => $variation->get_height(),
					'sku' => $variation->get_sku(),
					'date_created' => $variation->get_date_created()->format( 'Y-m-d H:i:s' ),
					'date_modified' => $variation->get_date_modified()->format( 'Y-m-d H:i:s' ),
				);

				// Get variation attributes
				$variation_attributes = $variation->get_attributes();
				$variation_data['attributes'] = array();
				foreach ( $variation_attributes as $attribute_name => $attribute_value ) {
					$variation_data['attributes'][$attribute_name] = $attribute_value;
				}

				// Get variation images
				$variation_data['images'] = $this->get_product_images( $variation );

				$variations[] = $variation_data;
			}
		}

		return $variations;
	}

	/**
	 * Fetch current app data from Lua backend.
	 *
	 * @since 1.0.0
	 */
	public function fetch_current_app_data() {
		// Check if onboarding is completed
		if ( ! get_option( 'lua_onboarding_completed', false ) ) {
			return false;
		}

		// Get stored data
		$user_id = get_option( 'lua_user_id', '' );
		$organization_id = get_option( 'lua_organization_id', '' );
		$agent_id = get_option( 'lua_agent_id', '' );
		$token = get_option( 'lua_token', '' );

		// Debug: Log the retrieved values

		// Check if we have all required data
		if ( empty( $user_id ) || empty( $organization_id ) || empty( $agent_id ) || empty( $token ) ) {
			return false;
		}

		// Build the URL
		$app_url = $this->get_api_url() . '/woocommerce/app/' . $organization_id . '/' . $agent_id . '/' . $user_id;
		

		// Make the GET request
		$response = wp_remote_get( $app_url, array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Accept' => 'application/json'
			),
			'timeout' => 30
		) );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		
		
		if ( $status_code >= 200 && $status_code < 300 ) {
			$app_data = json_decode( $body, true );
			
			// Always update stored data with fresh data from API
			if ( isset( $app_data['redirectUri'] ) ) {
				update_option( 'lua_redirect_uri', $app_data['redirectUri'] );
			}
			
			// Store the full app data for future use
			update_option( 'lua_app_data', $app_data );
			
			return $app_data;
		} else {
			return false;
		}
	}

	/**
	 * Fetch app data on all admin page loads.
	 *
	 * @since 1.0.0
	 */
	public function fetch_app_data_on_admin_load() {
		// Only run on WooCommerce admin pages
		if ( ! isset( $_GET['page'] ) || ( strpos( sanitize_text_field( wp_unslash( $_GET['page'] ) ), 'woocommerce' ) === false && sanitize_text_field( wp_unslash( $_GET['page'] ) ) !== 'wc-admin' ) ) {
			return;
		}
		
		
		// Fetch current app data
		$app_data = $this->fetch_current_app_data();
		
		if ( $app_data ) {
		} else {
		}
	}

	/**
	 * Register widget settings.
	 *
	 * @since 1.0.0
	 */
	public function register_widget_settings() {
		// Register settings
		register_setting( 'lua_widget_settings', 'lua_widget_enabled' );
		register_setting( 'lua_widget_settings', 'lua_widget_position' );
		register_setting( 'lua_widget_settings', 'lua_widget_theme' );
		register_setting( 'lua_widget_settings', 'lua_widget_button_text' );
		register_setting( 'lua_widget_settings', 'lua_widget_chat_title' );
		register_setting( 'lua_widget_settings', 'lua_widget_button_icon' );
		register_setting( 'lua_widget_settings', 'lua_widget_button_color' );
		register_setting( 'lua_widget_settings', 'lua_widget_chat_height' );
		register_setting( 'lua_widget_settings', 'lua_widget_chat_width' );
		register_setting( 'lua_widget_settings', 'lua_widget_voice_enabled' );
		register_setting( 'lua_widget_settings', 'lua_widget_bottom_position' );
		register_setting( 'lua_widget_settings', 'lua_widget_right_position' );

		// Handle form submission
		if ( isset( $_POST['lua_widget_settings_submit'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lua_widget_settings_nonce'] ) ), 'lua_widget_settings_action' ) ) {
			$this->save_widget_settings();
			wp_safe_redirect( admin_url( 'admin.php?page=lua-widget-settings&settings_saved=1' ) );
			exit;
		}
	}

	/**
	 * Save widget settings.
	 *
	 * @since 1.0.0
	 */
	private function save_widget_settings() {
		// Get store name for default values
		$store_name = get_bloginfo( 'name' );
		$default_assistant_text = $store_name . ' Assistant';
		
		$settings = array(
			'lua_widget_enabled' => isset( $_POST['lua_widget_enabled'] ) ? 1 : 0,
			'lua_widget_position' => sanitize_text_field( $_POST['lua_widget_position'] ?? 'bottom-right' ),
			'lua_widget_theme' => sanitize_text_field( $_POST['lua_widget_theme'] ?? 'light' ),
			'lua_widget_button_text' => sanitize_text_field( $_POST['lua_widget_button_text'] ?? $default_assistant_text ),
			'lua_widget_chat_title' => sanitize_text_field( $_POST['lua_widget_chat_title'] ?? $default_assistant_text ),
			'lua_widget_button_icon' => esc_url_raw( $_POST['lua_widget_button_icon'] ?? '' ),
			'lua_widget_button_color' => sanitize_hex_color( $_POST['lua_widget_button_color'] ?? '#000000' ),
			'lua_widget_chat_height' => absint( $_POST['lua_widget_chat_height'] ?? 600 ),
			'lua_widget_chat_width' => absint( $_POST['lua_widget_chat_width'] ?? 400 ),
			'lua_widget_voice_enabled' => isset( $_POST['lua_widget_voice_enabled'] ) ? 1 : 0,
			'lua_widget_bottom_position' => absint( $_POST['lua_widget_bottom_position'] ?? 75 ),
			'lua_widget_right_position' => absint( $_POST['lua_widget_right_position'] ?? 20 ),
		);

		foreach ( $settings as $key => $value ) {
			update_option( $key, $value );
		}
	}

	/**
	 * Widget settings page.
	 *
	 * @since 1.0.0
	 */
	public function widget_settings_page() {

		$settings = $this->get_widget_settings();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Lua Widget Settings', 'lua_shopping_assistant' ); ?></h1>
			
			<?php if ( isset( $_GET['settings_saved'] ) ) : ?>
				<div class="notice notice-success">
					<p><?php esc_html_e( 'Widget settings have been saved successfully!', 'lua_shopping_assistant' ); ?></p>
				</div>
			<?php endif; ?>

			<form method="post" action="">
				<?php wp_nonce_field( 'lua_widget_settings_action', 'lua_widget_settings_nonce' ); ?>
				
				<table class="form-table">
					<tr>
						<th scope="row"><?php esc_html_e( 'Enable Widget', 'lua_shopping_assistant' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="lua_widget_enabled" value="1" <?php checked( $settings['enabled'] ); ?>>
								<?php esc_html_e( 'Enable Lua Pop widget on storefront', 'lua_shopping_assistant' ); ?>
							</label>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Agent ID', 'lua_shopping_assistant' ); ?></th>
						<td>
							<input type="text" value="<?php echo esc_attr( $settings['agent_id'] ); ?>" class="regular-text" readonly />
							<p class="description"><?php esc_html_e( 'Agent ID is automatically set from your onboarding configuration', 'lua_shopping_assistant' ); ?></p>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Position', 'lua_shopping_assistant' ); ?></th>
						<td>
							<select name="lua_widget_position">
								<option value="bottom-right" <?php selected( $settings['position'], 'bottom-right' ); ?>><?php esc_html_e( 'Bottom Right', 'lua_shopping_assistant' ); ?></option>
								<option value="bottom-left" <?php selected( $settings['position'], 'bottom-left' ); ?>><?php esc_html_e( 'Bottom Left', 'lua_shopping_assistant' ); ?></option>
								<option value="top-right" <?php selected( $settings['position'], 'top-right' ); ?>><?php esc_html_e( 'Top Right', 'lua_shopping_assistant' ); ?></option>
								<option value="top-left" <?php selected( $settings['position'], 'top-left' ); ?>><?php esc_html_e( 'Top Left', 'lua_shopping_assistant' ); ?></option>
							</select>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Theme', 'lua_shopping_assistant' ); ?></th>
						<td>
							<select name="lua_widget_theme">
								<option value="light" <?php selected( $settings['theme'], 'light' ); ?>><?php esc_html_e( 'Light', 'lua_shopping_assistant' ); ?></option>
								<option value="dark" <?php selected( $settings['theme'], 'dark' ); ?>><?php esc_html_e( 'Dark', 'lua_shopping_assistant' ); ?></option>
							</select>
						</td>
					</tr>
					
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Button Text', 'lua_shopping_assistant' ); ?></th>
						<td>
							<input type="text" name="lua_widget_button_text" value="<?php echo esc_attr( $settings['button_text'] ); ?>" class="regular-text" />
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Chat Title', 'lua_shopping_assistant' ); ?></th>
						<td>
							<input type="text" name="lua_widget_chat_title" value="<?php echo esc_attr( $settings['chat_title'] ); ?>" class="regular-text" />
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Button Icon URL', 'lua_shopping_assistant' ); ?></th>
						<td>
							<input type="url" name="lua_widget_button_icon" value="<?php echo esc_attr( $settings['button_icon'] ); ?>" class="regular-text" />
							<p class="description"><?php esc_html_e( 'URL to the button icon image', 'lua_shopping_assistant' ); ?></p>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Button Color', 'lua_shopping_assistant' ); ?></th>
						<td>
							<input type="color" name="lua_widget_button_color" value="<?php echo esc_attr( $settings['button_color'] ); ?>" />
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Chat Window Height', 'lua_shopping_assistant' ); ?></th>
						<td>
							<input type="number" name="lua_widget_chat_height" value="<?php echo esc_attr( $settings['chat_height'] ); ?>" min="300" max="800" />
							<p class="description"><?php esc_html_e( 'Height in pixels (300-800)', 'lua_shopping_assistant' ); ?></p>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Chat Window Width', 'lua_shopping_assistant' ); ?></th>
						<td>
							<input type="number" name="lua_widget_chat_width" value="<?php echo esc_attr( $settings['chat_width'] ); ?>" min="300" max="600" />
							<p class="description"><?php esc_html_e( 'Width in pixels (300-600)', 'lua_shopping_assistant' ); ?></p>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Voice Mode', 'lua_shopping_assistant' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="lua_widget_voice_enabled" value="1" <?php checked( $settings['voice_enabled'] ); ?>>
								<?php esc_html_e( 'Enable voice mode', 'lua_shopping_assistant' ); ?>
							</label>
						</td>
					</tr>
				</table>
				
				<h2><?php esc_html_e( 'Button Position', 'lua_shopping_assistant' ); ?></h2>
				<p><?php esc_html_e( 'Fine-tune the exact position of the chat button on your storefront.', 'lua_shopping_assistant' ); ?></p>
				
				<table class="form-table">
					<tr>
						<th scope="row"><?php esc_html_e( 'Bottom Position', 'lua_shopping_assistant' ); ?></th>
						<td>
							<input type="range" name="lua_widget_bottom_position" min="0" max="200" value="<?php echo esc_attr( $settings['bottom_position'] ); ?>" class="lua-position-slider" id="bottom-slider" />
							<span class="lua-position-value"><?php echo esc_html( $settings['bottom_position'] ); ?>px</span>
							<p class="description"><?php esc_html_e( 'Distance from bottom of screen (0-200px)', 'lua_shopping_assistant' ); ?></p>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php esc_html_e( 'Right Position', 'lua_shopping_assistant' ); ?></th>
						<td>
							<input type="range" name="lua_widget_right_position" min="0" max="200" value="<?php echo esc_attr( $settings['right_position'] ); ?>" class="lua-position-slider" id="right-slider" />
							<span class="lua-position-value"><?php echo esc_html( $settings['right_position'] ); ?>px</span>
							<p class="description"><?php esc_html_e( 'Distance from right edge of screen (0-200px)', 'lua_shopping_assistant' ); ?></p>
						</td>
					</tr>
				</table>
				
				<style>
				.lua-position-slider {
					width: 200px;
					margin-right: 10px;
				}
				.lua-position-value {
					font-weight: bold;
					color: #0073aa;
					min-width: 50px;
					display: inline-block;
				}
				</style>
				
				<script>
				document.addEventListener('DOMContentLoaded', function() {
					const bottomSlider = document.getElementById('bottom-slider');
					const rightSlider = document.getElementById('right-slider');
					
					if (bottomSlider) {
						bottomSlider.addEventListener('input', function() {
							this.nextElementSibling.textContent = this.value + 'px';
						});
					}
					
					if (rightSlider) {
						rightSlider.addEventListener('input', function() {
							this.nextElementSibling.textContent = this.value + 'px';
						});
					}
				});
				</script>
				
				<?php submit_button( __( 'Save Settings', 'lua_shopping_assistant' ), 'primary', 'lua_widget_settings_submit' ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Get widget settings.
	 *
	 * @return array Widget settings.
	 * @since 1.0.0
	 */
	private function get_widget_settings() {
		// Get agent ID from stored onboarding data
		$agent_id = get_option( 'lua_agent_id', '' );
		
		// Get environment from config (determined at build time)
		$environment = defined( 'LUA_ENVIRONMENT' ) ? LUA_ENVIRONMENT : 'production';
		
		// Get store name for default button text and chat title
		$store_name = get_bloginfo( 'name' );
		$default_assistant_text = $store_name . ' Assistant';
		
		return array(
			'enabled' => get_option( 'lua_widget_enabled', 0 ),
			'agent_id' => $agent_id,
			'position' => get_option( 'lua_widget_position', 'bottom-right' ),
			'theme' => get_option( 'lua_widget_theme', 'light' ),
			'environment' => $environment,
			'button_text' => get_option( 'lua_widget_button_text', $default_assistant_text ),
			'chat_title' => get_option( 'lua_widget_chat_title', $default_assistant_text ),
			'button_icon' => get_option( 'lua_widget_button_icon', '' ),
			'button_color' => get_option( 'lua_widget_button_color', '#000000' ),
			'chat_height' => get_option( 'lua_widget_chat_height', 600 ),
			'chat_width' => get_option( 'lua_widget_chat_width', 400 ),
			'voice_enabled' => get_option( 'lua_widget_voice_enabled', 1 ),
			'bottom_position' => get_option( 'lua_widget_bottom_position', 75 ),
			'right_position' => get_option( 'lua_widget_right_position', 20 ),
		);
	}

	/**
	 * Enqueue frontend scripts.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_frontend_scripts() {
		$settings = $this->get_widget_settings();
		
		if ( ! $settings['enabled'] ) {
			return;
		}

		// Enqueue Lua Pop script
		wp_enqueue_script( 
			'lua-pop', 
			'https://lua-ai-global.github.io/lua-pop/lua-pop.umd.js', 
			array(), 
			'1.0.0', 
			true 
		);
	}

	/**
	 * Render Lua Pop widget.
	 *
	 * @since 1.0.0
	 */
	public function render_lua_pop_widget() {
		$settings = $this->get_widget_settings();
		
		if ( ! $settings['enabled'] ) {
			return;
		}

		// Generate session ID if not exists
		$session_id = $this->get_or_create_session_id();
		
		// Build positional styles object
		$positional_styles = array(
			'bottom' => $settings['bottom_position'] . 'px',
			'right' => $settings['right_position'] . 'px'
		);

		// Build configuration object
		$config = array(
			'sessionId' => $session_id,
			'agentId' => $settings['agent_id'],
			'position' => $settings['position'],
			'theme' => $settings['theme'],
			'environment' => $settings['environment'],
			'buttonText' => $settings['button_text'],
			'chatTitle' => $settings['chat_title'],
			'buttonIcon' => $settings['button_icon'],
			'buttonColor' => $settings['button_color'],
			'chatWindowHeight' => $settings['chat_height'],
			'chatWindowWidth' => $settings['chat_width'],
			'voiceModeEnabled' => (bool) $settings['voice_enabled'],
			'popupButtonStyles' => null,
			'runtimeContext' => null,
			'popupButtonPositionalContainerStyles' => $positional_styles,
			'chatTitleHeaderStyles' => null
		);

		?>
		<script>
		// Create session if not exists
		if (!localStorage.getItem('lua_session_id')) {
			localStorage.setItem(
				'lua_session_id',  
				'sess-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9)
			);
		}   
			
		var sessionId = localStorage.getItem('lua_session_id');

		// Initialize Lua Pop when script is loaded
		document.addEventListener('DOMContentLoaded', function() {
			if (typeof window.LuaPop !== 'undefined') {
				window.LuaPop.init(<?php echo wp_json_encode( $config ); ?>);
			} else {
				// Fallback if script loads after DOMContentLoaded
				window.addEventListener('load', function() {
					if (typeof window.LuaPop !== 'undefined') {
						window.LuaPop.init(<?php echo wp_json_encode( $config ); ?>);
					}
				});
			}
		});
		</script>
		<?php
	}

	/**
	 * Get or create session ID.
	 *
	 * @return string Session ID.
	 * @since 1.0.0
	 */
	private function get_or_create_session_id() {
		// This will be handled by JavaScript, but we provide a fallback
		return 'sess-' . time() . '-' . wp_generate_password( 9, false );
	}

	/**
	 * Get orders count (HPOS-compatible).
	 *
	 * @return int Orders count.
	 * @since 1.0.0
	 */
	private function get_orders_count() {
		// HPOS-compatible order count
		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			// Use HPOS-compatible count
			$orders = wc_get_orders( array(
				'status' => 'any',
				'limit' => -1,
				'return' => 'ids',
			) );
			return count( $orders );
		} else {
			// Use traditional WordPress count
			return wp_count_posts( 'shop_order' )->publish;
		}
	}
}
}
